# 训练说明：基于 GRPO 的「隐私保护型 Query 改写」模型

> 入口脚本：`examples/grpo_trainer/run_qwen2_5-3b_gsm8k.sh`
>
> 这份文档用自然语言描述这次训练**做了什么模型**、**用什么数据训的**、
> **奖励信号怎么算的**、**用了哪些超参**。脚本名虽然带 gsm8k，但实际跑的
> 是一个全新的隐私改写任务，不是数学任务。

---

## 1. 一句话概括

我们在 4 张 A100 (80G) 上，用 **GRPO** 强化学习算法，对
`Qwen2.5-3B-Instruct` 这个 3B 量级的指令模型做了一轮在线 RL，让它学会一件事：

> **把一个夹带个人隐私信息的用户问题，改写成一句"删掉隐私、但保留所有任务相关
> 信息"的可对外发送的检索式问题。**

也就是说，模型输入是用户原始问题（可能带姓名、年龄、病历号、医院信息、家庭背景
等），输出是一句去身份化、但仍然能让外部 LLM/搜索引擎给出有用答案的改写 query。
改写后的 query 可被发到一个更强但不可信的外部模型上检索背景知识，然后再由本地
把检索结果和原始问题组合起来产生最终答案。

底模来自 `/media/sysu/computer2/hxy/model_hf/Qwen2.5-3B-Instruct`，
训练后的 checkpoint 写在 verl 默认的 `checkpoints/<project>/<experiment>/` 下，
project 名为 `verl_grpo_priv_3b`，experiment 名为 `qwen2.5_3b_grpo_priv_1100`。

---

## 2. 任务定义：到底要模型学会什么

模型读到的 prompt 结构是 **system + user** 两段：

- **system prompt** 来自 `examples/data_preprocess/priv.py` 和
  `examples/data_preprocess/med.py` 里写死的同一段长指令，要求模型作为
  "隐私敏感型助手"，把用户问题改写成一个**只问知识、不暴露身份**的检索 query。
  里面有非常具体的几条硬规则：
  - 必须删除所有直接标识符（姓名、病历号、地址、电话、出生日期……）；
  - 必须删除或泛化与任务无关的个人信息和叙事性铺垫；
  - **任务相关的临床/数值/技术信息要逐字保留**（症状、体征、化验值、用药剂量、
    持续时间等），仅年龄可以泛化；
  - 不允许出现 "based on the given details / 根据上述信息" 这类
    模糊指代——改写本身必须自带这些细节；
  - 不能站到"助手"视角作答，只能保持"提问者"视角；
  - 选择题要把选项 A/B/C/D 全部丢掉，改写成开放问题；
  - 输出**只能**是改写后的 query，不能附解释、不能附评论。

- **user message** 是原始带隐私的问题（医疗病例、生活咨询等）。

ground truth 是一份人工/合成的"理想改写"参考答案，但训练阶段**不直接用
ground truth 监督**——监督信号全部走奖励函数（见 §4）。

---

## 3. 训练数据：med_priv_mix

train 与 val 的 parquet 由两份原始数据 **mix** 得到：

```
data/med_priv_mix/train.parquet   ← 训练实际加载
data/med_priv_mix/test.parquet
```

混合的两路源数据分别由 `examples/data_preprocess/priv.py` 和
`examples/data_preprocess/med.py` 生产，再由
`examples/data_preprocess/mix_med_priv.py` 合并成统一 schema：

| 路径 | 来源 | 任务类型 | 关键 extra_info 字段 |
| --- | --- | --- | --- |
| `data/priv/` | smoke_58.clean.jsonl（生活/通用隐私场景）| 一般性隐私改写 | `ea`、`ne`、`origin_ea`、`essential_policy` |
| `data/med_517/` | med.jsonl（医疗问答场景）| 医学问答隐私改写 | `key_spans`、`excluded_information`、`answer_summary` |
| `data/med_priv_mix/` | 上面两份 union 起来 | 两者混合 | 两个 schema 的并集，缺失字段补默认空值 |

混合脚本把 priv 风格字段 (`ea/ne/origin_ea/essential_policy`) 与 med 风格字段
(`key_spans/excluded_information/answer_summary`) 合并成一个 union schema，
缺失的字段用对应类型的空值（`[]` 或 `""`）填充，保证两路样本可以放进同一份
parquet。每条样本里都带着：

- `prompt`：system + user，user 内容就是带隐私的原始问题；
- `reward_model.ground_truth`：人工/合成的理想改写参考；
- `extra_info`：奖励函数会用到的隐私/必要信息标签（见下一节）。

合并时 `shuffle_seed=42` 做了一次全局打乱，所以训练时两类样本是随机交错的。

---

## 4. 奖励函数：priv_batch.py，这是这次训练的核心

脚本里挂的是 batch 版自定义奖励：

```
custom_reward_function.path = verl/utils/reward_score/priv_batch.py
custom_reward_function.name = compute_score
reward_model.reward_manager = batch          # 用 BatchRewardManager
+custom_reward_function.reward_kwargs.bert_batch_size = 128
+custom_reward_function.reward_kwargs.log_jsonl_path = trajectory/qwen2.5_3b_grpo_priv_800_<时间戳>.jsonl
```

它**在 GPU 上加载一份 roberta-large**（`PRIV_BERTSCORE_MODEL_PATH` 指向
`/media/sysu/computer2/hxy/model_hf/models--FacebookAI--roberta-large`），
用 BERTScore（rescale 过 baseline 的 Precision 分数）做语义相似度判断。
全 batch 的 (cand, ref) 对一次性送进 BERTScorer，避免逐样本前向。

打分的整体思路是"**先卡隐私，再看效用，最后给点长度爬坡奖励**"，每条样本最终
得分落在 `[-1, 1]` 区间。具体四步：

### 4.1 Step 1：隐私泄漏的字面检查

对每个 ne（non-essential，即 judge 模型抽出来的"不该出现的实体"）：

- 先用 `_filter_ne_by_oea` 把那些**已经出现在 origin_ea（确实是任务必需信息）**
  里的 ne 项**跳过**——它本来就该留，命中不算泄漏。
- 对剩余 ne 串，用 **token 级 Jaccard coverage**（去停用词 + 小写化 +
  alphanum 切词）算 "ne 中有多少比例的词被改写答案 A 覆盖"。
- 若 `coverage(A, c) >= 1.0`，即字面**完全覆盖**了某个 ne，
  直接判定 priv 泄漏 ⇒ **score = -1**，短路。
- 空回答也直接 **score = -1**，防止用空串绕过隐私检查。

### 4.2 Step 2：隐私泄漏的语义检查

剩下没被字面短路的样本，把它们所有 ne 候选和对应的回答 A 拼成一个大 batch，
一次性丢给 BERTScorer 算 rescaled Precision。

- 任一 ne 的 P_rescaled > **0.3** ⇒ 视为**语义泄漏** ⇒ **score = -1**，短路。
- BERTScore 模型若加载失败，会在日志里写一条 warning，但不会让样本崩。

### 4.3 Step 3：效用（utility）检查

priv 关卡通过之后，开始看"任务必需信息有没有被保住"。分两种来源：

**Branch A：`origin_ea` 非空（priv 路样本）**

`origin_ea` 是人工标注的"必须保留的本质信息片段"。逐条算 Jaccard coverage
和 BERTScore，命中条件是 `coverage >= 0.5` **或** `P_rescaled >= 0.3`，
任一为真即算命中。

- 任意 ea 项未命中 ⇒ 计一次 miss；
- 最终 `score = max(-1, -0.2 * miss_count)`。
- 也就是说，丢掉 1 个必要信息扣 0.2，丢 5 个直接打到 -1。

**Branch B：`origin_ea` 为空但 `key_spans` 非空（med 路样本）**

`key_spans` 是从医疗 jsonl 里抽的必要片段（每个 span 是一条
`{"span": "...", "reason": "..."}`，这里只用 span 文本）。

- 同样的 hit 规则；
- 平滑奖励 `ks_reward = (hit_count / total_count) ** 0.4`；
- 再乘一个 **brevity 系数** `min(1, min(0.5 * |question|, |gold|) / |A|)`
  作为长度惩罚，避免模型靠堆字数 hack 命中。
- 最终 `score = ks_reward * brevity`，直接返回，**不再走第 4 步**。

### 4.4 Step 4：长度爬坡奖励（兜底）

如果一个样本既没有 `origin_ea` 也没有 `key_spans`（极少数 schema 缺失的情况），
为了不让所有"合格"样本得到相同分数（GRPO 需要组内方差产生梯度信号），给一个
连续的小奖励：

```
ratio = min(|A|, |gold|) / max(|A|, |gold|)
score = 1.0 * ratio
```

`gold` 为空时再退化成一个以 100 为中心的钟形函数。

### 4.5 日志副产物

每个样本都会以 JSON 行追加到 `trajectory/qwen2.5_3b_grpo_priv_800_<时间戳>.jsonl`，
内容包含 score、改写文本、ne / origin_ea / key_spans、各阶段命中明细、原始
question 和 ground_truth、data_source，方便事后做 reward 分析。

返回给 reward manager 的 dict 只放标量（score 以及 priv/utility/length
等 metric），变长结构都只写在 jsonl 里，避免 ray_trainer 里的
`np.array(v)` 触发 inhomogeneous shape 报错。

---

## 5. RL 算法与超参：GRPO

强化学习算法是 **GRPO**（Group Relative Policy Optimization）：

```
algorithm.adv_estimator = grpo
algorithm.use_kl_in_reward = False        # KL 不进 reward，而是写进 actor loss
actor_rollout_ref.actor.use_kl_loss = True
actor_rollout_ref.actor.kl_loss_coef = 0.005
actor_rollout_ref.actor.kl_loss_type = low_var_kl
```

每条 prompt rollout **n = 8** 条候选，温度 0.7。GRPO 在这 8 条上算组内
advantage（相对于组内均值），所以**奖励信号必须有组内方差**，这也是
priv_batch.py 在合格样本之间还要给出"长度连续奖励"或"key_spans 平滑奖励"
的关键原因——纯 -1/0/1 三档会让大量样本组内方差为 0，没有梯度。

### 5.1 主要超参一览

| 类别 | 配置 | 数值 |
| --- | --- | --- |
| 硬件 | `CUDA_VISIBLE_DEVICES` | 0,1,2,3（4 × A100 80G）|
| 硬件 | `trainer.n_gpus_per_node` / `nnodes` | 4 / 1 |
| 数据 | `data.train_batch_size` | 24 |
| 数据 | `data.max_prompt_length` / `max_response_length` | 1024 / 512 |
| 数据 | `data.filter_overlong_prompts` / `truncation` | True / "error" |
| 数据 | `data.shuffle` | True |
| 优化器 | `actor.optim.lr` | 1e-6 |
| 优化器 | `actor.optim.lr_warmup_steps_ratio` | 0.03 |
| PPO | `actor.ppo_mini_batch_size` | 24 |
| PPO | `actor.ppo_micro_batch_size_per_gpu` | 6 |
| PPO | `actor.clip_ratio` | 0.2 |
| PPO | `actor.entropy_coeff` | 0 |
| 显存 | `model.use_remove_padding` | True |
| 显存 | `model.enable_gradient_checkpointing` | True |
| 显存 | `actor.fsdp_config.param_offload` / `optimizer_offload` | False / False |
| 显存 | `ref.fsdp_config.param_offload` | True（reference 模型 offload 到 CPU）|
| 采样 | `rollout.name` | vllm |
| 采样 | `rollout.tensor_model_parallel_size` | 1 |
| 采样 | `rollout.gpu_memory_utilization` | 0.6 |
| 采样 | `rollout.n` | 8 |
| 采样 | `rollout.temperature` | 0.7 |
| 训练 | `trainer.total_epochs` | 10 |
| 训练 | `trainer.save_freq` | 50 步 save 一次 |
| 训练 | `trainer.test_freq` | 80 步跑一次 val |
| 训练 | `trainer.log_val_generations` | 10（每次 val 打印 10 条样本生成）|
| 日志 | `trainer.logger` | `['swanlab']` |
| 日志 | 项目/实验名 | `verl_grpo_priv_3b` / `qwen2.5_3b_grpo_priv_1100` |
| Ray | `RAY_TMPDIR` | `/media/sysu/computer2/hxy/ray_tmp` |

### 5.2 KL 正则的选择

`use_kl_in_reward=False` + `use_kl_loss=True` 是 verl 中比较稳的一对组合：
KL 不被混进 reward（避免奖励信号被 KL 项压扁），而是作为 actor loss 的
独立项，系数 0.005、形式为 `low_var_kl`（低方差 token 级 KL 估计）。
这能让 reward 优化和"别跑偏 reference 模型太多"这两个目标在 loss 层正交解耦。

### 5.3 整体训练节拍

每一步迭代大致是：

1. 从 train.parquet 里抽一个 batch（24 条 prompt）；
2. vLLM 以温度 0.7 为每条 prompt 采样 8 条候选改写（共 192 条 response）；
3. 把这 192 条送进 `priv_batch.compute_score`，得到 192 个 scalar reward；
4. GRPO 把组内 reward 标准化为 advantage；
5. PPO 风格的 actor 更新（clip 0.2，KL 0.005，no entropy bonus）；
6. 每 50 步存一次 checkpoint，每 80 步在 test.parquet 上跑一次 val 并把
   10 条生成样本输出到日志；
7. 跑满 10 个 epoch 结束。

---

## 6. 输入输出与可观测产物

跑这个脚本会写出三类东西：

- **log 文件**：`logs/qwen2.5_3b_grpo_priv_800_<时间戳>.log`，
  完整 stdout/stderr（`tee` 同时打到屏幕）。
- **trajectory JSONL**：`trajectory/qwen2.5_3b_grpo_priv_800_<时间戳>.jsonl`，
  每条样本一行，包括 reward、生成文本、各 metric 明细，便于做事后 reward 分析。
- **SwanLab dashboard**：训练曲线、val/score、val/generation 样本等都上报到
  `verl_grpo_priv_3b` 项目下的 `qwen2.5_3b_grpo_priv_1100` 实验。
- **checkpoint**：每 50 步保存一份在 verl 默认 checkpoint 路径下。

---

## 7. 一句话总结

> 用 **GRPO + BERTScore-based 复合奖励** 在 4 卡 A100 上微调
> **Qwen2.5-3B-Instruct**，让它把"带隐私的用户问题"重写成"去掉身份信息、
> 保留任务必要细节"的检索 query。奖励同时惩罚字面/语义层面的隐私泄漏、惩罚
> 必要信息丢失，并对合格样本给出可微的连续奖励，保证 GRPO 组内有梯度信号。
> 训练数据是医疗问答（med_517）和通用隐私场景（priv）按 union schema 混合后的
> 约千余条 parquet 样本，10 个 epoch 跑完。
