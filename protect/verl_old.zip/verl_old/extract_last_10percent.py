#!/usr/bin/env python3
"""统计 jsonl 文件总行数，并按百分比区间提取行到新文件。

支持两种模式:
    1) 尾部比例:   --ratio 0.1            => 提取倒数 10% 的行
    2) 区间百分比: --start 80 --end 90    => 提取从 80% 到 90% 位置的行
       （--start / --end 可写 0~100 的百分数，也可写 0~1 的小数）

用法:
    python extract_last_10percent.py --input <input.jsonl> [--output <output.jsonl>] [--ratio 0.1]
    python extract_last_10percent.py --input <input.jsonl> --start 80 --end 90

若未指定 --output，则默认在输入文件同目录下生成
    <stem>_last10pct.jsonl        (尾部模式)
    <stem>_p{a}-p{b}.jsonl        (区间模式)
"""

import argparse
import os
import sys


DEFAULT_INPUT = "/media/sysu/computer2/hxy/verl_old/trajectory/qwen2.5_3b_grpo_priv_800_20260517_032506.jsonl"


def count_lines(path: str) -> int:
    total = 0
    with open(path, "rb") as f:
        for _ in f:
            total += 1
    return total


def normalize_pct(value: float) -> float:
    """把百分比统一成 0~1 的小数。允许 0~100 或 0~1 两种写法。"""
    if value > 1:
        value = value / 100.0
    return value


def extract_range(input_path: str, output_path: str, start_ratio: float, end_ratio: float) -> tuple[int, int, int, int]:
    """按 [start_ratio, end_ratio) 区间提取行，返回 (total, start_idx, end_idx, written)。"""
    total = count_lines(input_path)
    start_idx = int(total * start_ratio)
    end_idx = int(total * end_ratio)
    if end_idx <= start_idx and total > 0:
        end_idx = min(total, start_idx + 1)

    written = 0
    with open(input_path, "r", encoding="utf-8") as fin, \
            open(output_path, "w", encoding="utf-8") as fout:
        for idx, line in enumerate(fin):
            if idx >= end_idx:
                break
            if idx >= start_idx:
                fout.write(line)
                written += 1

    return total, start_idx, end_idx, written


def main() -> int:
    parser = argparse.ArgumentParser(description="按百分比区间提取 jsonl 文件的行")
    parser.add_argument("--input", default=DEFAULT_INPUT, help="输入 jsonl 文件路径")
    parser.add_argument("--output", default=None, help="输出文件路径（可选）")
    parser.add_argument("--ratio", type=float, default=None,
                        help="尾部比例，例如 0.1 表示倒数 10%%（与 --start/--end 互斥）")
    parser.add_argument("--start", type=float, default=10,
                        help="区间起点百分比，0~100 或 0~1，例如 80 表示从 80%% 处开始")
    parser.add_argument("--end", type=float, default=25,
                        help="区间终点百分比，0~100 或 0~1，例如 90 表示到 90%% 处结束")
    args = parser.parse_args()

    if not os.path.isfile(args.input):
        print(f"[错误] 输入文件不存在: {args.input}", file=sys.stderr)
        return 1

    use_range = args.start is not None or args.end is not None
    use_tail = args.ratio is not None

    if use_range and use_tail:
        print("[错误] --ratio 与 --start/--end 不能同时使用", file=sys.stderr)
        return 1

    if use_range:
        if args.start is None or args.end is None:
            print("[错误] 使用区间模式时必须同时提供 --start 和 --end", file=sys.stderr)
            return 1
        start_ratio = normalize_pct(args.start)
        end_ratio = normalize_pct(args.end)
    else:
        ratio = args.ratio if args.ratio is not None else 0.1
        ratio = normalize_pct(ratio)
        if not (0 < ratio <= 1):
            print(f"[错误] ratio 必须在 (0, 1] 范围内，当前: {ratio}", file=sys.stderr)
            return 1
        start_ratio = 1.0 - ratio
        end_ratio = 1.0

    if not (0 <= start_ratio < end_ratio <= 1):
        print(f"[错误] 非法区间: start={start_ratio}, end={end_ratio}", file=sys.stderr)
        return 1

    if args.output is None:
        stem, ext = os.path.splitext(args.input)
        if use_range:
            a = int(round(start_ratio * 100))
            b = int(round(end_ratio * 100))
            args.output = f"{stem}_p{a}-p{b}{ext}"
        else:
            pct = int(round((end_ratio - start_ratio) * 100))
            args.output = f"{stem}_last{pct}pct{ext}"

    total, start_idx, end_idx, written = extract_range(
        args.input, args.output, start_ratio, end_ratio
    )

    print(f"输入文件: {args.input}")
    print(f"总行数:   {total}")
    print(f"区间:     [{start_ratio * 100:.2f}%, {end_ratio * 100:.2f}%)  "
          f"=> 行索引 [{start_idx}, {end_idx})")
    print(f"提取行数: {written}")
    print(f"输出文件: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
