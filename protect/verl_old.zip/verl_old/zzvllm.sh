export CUDA_VISIBLE_DEVICES=0
# export CUDA_VISIBLE_DEVICES=0,1
python3 -m vllm.entrypoints.openai.api_server \
    --model /media/sysu/computer2/hxy/model_hf/Qwen2.5-0.5B-Instruct \
    --port 8000 \
    --max-model-len 8192 \
    --tensor-parallel-size 1 \
    --disable-custom-all-reduce

