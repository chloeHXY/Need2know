# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Mix the ``med_517`` and ``priv`` parquet datasets into a single parquet pair.

输入（默认值）:
    /media/sysu/computer2/hxy/verl_old/data/med_517/train.parquet
    /media/sysu/computer2/hxy/verl_old/data/med_517/test.parquet
    /media/sysu/computer2/hxy/verl_old/data/priv/train.parquet
    /media/sysu/computer2/hxy/verl_old/data/priv/test.parquet

输出（默认值）:
    <local_dir>/train.parquet
    <local_dir>/test.parquet

两个数据源的 ``extra_info`` 字段不同（priv: ea/ne/origin_ea/essential_policy；
med: key_spans/excluded_information/answer_summary），脚本会取两者并集，
为缺失字段填入与原始 schema 一致的空值，保证 parquet schema 可以对齐。
"""

import argparse
import os
import random
from pathlib import Path
from typing import Any

import datasets


PRIV_EXTRA_DEFAULTS: dict[str, Any] = {
    "ea": [],
    "ne": [],
    "origin_ea": [],
    "essential_policy": "",
}

MED_EXTRA_DEFAULTS: dict[str, Any] = {
    "key_spans": [],          # list[{"span": str, "reason": str}]
    "excluded_information": [],  # list[{"text": str, "reason": str}]
    "answer_summary": "",
}

UNION_EXTRA_DEFAULTS: dict[str, Any] = {**PRIV_EXTRA_DEFAULTS, **MED_EXTRA_DEFAULTS}


def _coerce_extra_info(extra: dict | None, split: str, idx: int) -> dict:
    """把单条样本的 extra_info 补齐到 union schema 上。

    - 保留原有键值；
    - 对缺失的 ea/ne/origin_ea/key_spans/excluded_information 填 []；
    - 对缺失的 essential_policy/answer_summary 填 ""；
    - 保证 split/index/answer/question 一定存在。
    """
    extra = dict(extra or {})

    extra.setdefault("split", split)
    extra.setdefault("index", idx)
    extra.setdefault("answer", "")
    extra.setdefault("question", "")

    for key, default in UNION_EXTRA_DEFAULTS.items():
        if key not in extra or extra[key] is None:
            extra[key] = [] if isinstance(default, list) else type(default)()

    return extra


def _normalize_record(record: dict, split: str, idx: int) -> dict:
    """把一条样本 normalize 成统一的 schema。"""
    prompt = record.get("prompt") or []
    if not isinstance(prompt, list):
        prompt = list(prompt)

    reward_model = dict(record.get("reward_model") or {})
    reward_model.setdefault("style", "rule")
    reward_model.setdefault("ground_truth", "")

    return {
        "data_source": str(record.get("data_source") or "priv"),
        "prompt": [
            {"role": str(m.get("role", "user")), "content": str(m.get("content", ""))}
            for m in prompt
        ],
        "ability": str(record.get("ability") or ""),
        "reward_model": {
            "style": str(reward_model.get("style", "rule")),
            "ground_truth": str(reward_model.get("ground_truth", "")),
        },
        "extra_info": _coerce_extra_info(record.get("extra_info"), split, idx),
    }


def _load_parquet_as_records(path: str | os.PathLike) -> list[dict]:
    """读 parquet 为 python list[dict]，方便后续 normalize / 合并。"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"parquet not found: {p}")
    ds = datasets.Dataset.from_parquet(str(p))
    return [dict(row) for row in ds]


def mix_split(
    med_path: str,
    priv_path: str,
    split: str,
    shuffle_seed: int | None,
) -> datasets.Dataset:
    med_records = _load_parquet_as_records(med_path)
    priv_records = _load_parquet_as_records(priv_path)

    merged: list[dict] = []
    for rec in med_records:
        merged.append(rec)
    for rec in priv_records:
        merged.append(rec)

    if shuffle_seed is not None:
        rng = random.Random(shuffle_seed)
        rng.shuffle(merged)

    normalized = [_normalize_record(r, split, i) for i, r in enumerate(merged)]

    print(
        f"[mix] split={split} med={len(med_records)} priv={len(priv_records)} "
        f"total={len(normalized)} (shuffle_seed={shuffle_seed})"
    )

    return datasets.Dataset.from_list(normalized)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--med_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/med_519",
        help="med 数据所在目录，应包含 train.parquet / test.parquet",
    )
    parser.add_argument(
        "--priv_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/priv_519",
        help="priv 数据所在目录，应包含 train.parquet / test.parquet",
    )
    parser.add_argument(
        "--local_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/med_priv_mix_519",
        help="输出目录，会在此目录下写 train.parquet / test.parquet",
    )
    parser.add_argument(
        "--train_name",
        default="train.parquet",
        help="train 输出文件名",
    )
    parser.add_argument(
        "--test_name",
        default="test.parquet",
        help="test 输出文件名",
    )
    parser.add_argument(
        "--shuffle_seed",
        type=int,
        default=42,
        help="混合后 shuffle 的随机种子；传 -1 表示不 shuffle。",
    )
    args = parser.parse_args()

    shuffle_seed: int | None = None if args.shuffle_seed < 0 else args.shuffle_seed

    os.makedirs(args.local_dir, exist_ok=True)

    train_ds = mix_split(
        med_path=os.path.join(args.med_dir, "train.parquet"),
        priv_path=os.path.join(args.priv_dir, "train.parquet"),
        split="train",
        shuffle_seed=shuffle_seed,
    )
    train_out = os.path.join(args.local_dir, args.train_name)
    train_ds.to_parquet(train_out)
    print(f"[mix] wrote {len(train_ds)} train samples -> {train_out}")

    test_ds = mix_split(
        med_path=os.path.join(args.med_dir, "test.parquet"),
        priv_path=os.path.join(args.priv_dir, "test.parquet"),
        split="test",
        shuffle_seed=shuffle_seed,
    )
    test_out = os.path.join(args.local_dir, args.test_name)
    test_ds.to_parquet(test_out)
    print(f"[mix] wrote {len(test_ds)} test  samples -> {test_out}")


if __name__ == "__main__":
    main()
