# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Preprocess the priv (smoke.clean) dataset to parquet format for verl.

输入: 一个 jsonl 文件，每行一个样本（参考 data/priv/smoke.clean.jsonl）。
输出: 默认在 --local_dir 下生成 train.parquet（可选 test.parquet）。

字段映射约定（与 data/gsm8k/data_read.md 中的指引保持一致）:
    data_source                     -> "priv"
    prompt                          -> [system?, user(raw_prompt)]
    ability                         -> "privacy"
    reward_model.style              -> "rule"
    reward_model.ground_truth       -> gold_reformulation
    extra_info.answer               -> gold_reformulation
    extra_info.question             -> raw_prompt
    extra_info.split                -> "train" / "test"
    extra_info.index                -> 行号 idx
    extra_info.id                   -> 原样本 id 删掉了@huangxinyue
    extra_info.ea                   -> judge_out.essential_attributes（judge 模型抽到的 essential）
    extra_info.ne                   -> judge_out.nonessential_attributes（judge 模型抽到的 non-essential）
    extra_info.origin_ea            -> [item.value for item in spec.essential_info]
                                       （人工标注的原始 essential 取值，list[str]，与 ea/ne 同构）
    extra_info.origin_ea_full       -> spec.essential_info（保留 attribute/value 原结构）
    extra_info.essential_policy     -> spec.essential_policy（"none" / "domain" / "addressed_person"）
"""

import argparse
import json
import os
from pathlib import Path

import datasets

from verl.utils.hdfs_io import copy, makedirs


DEFAULT_SYSTEM_PROMPT = """
You are a privacy-conscious assistant that rewrites a user's request into an information-seeking query that can be safely sent to an external knowledge source (e.g. a stronger LLM or a search engine). The rewritten query will be used to retrieve background knowledge that the user will then combine with the original request to produce the final answer locally. The rewrite therefore does NOT need to mirror the original surface form (e.g. it does not need to remain a multiple-choice question); it only needs to be a clean information request that returns the knowledge required to solve the underlying task.

The rewrite must:
- Remove every direct identifier, real or synthetic: personal names, patient / chart / record IDs, addresses, phone numbers, dates of birth, account numbers, etc.
- Remove or generalize information that is not needed to solve the underlying task (unrelated personal details, narrative framing, irrelevant social context).
- KEEP every piece of task-relevant information VERBATIM, except for age information, which should be generalized as described above. Do not paraphrase clinical findings, lab values, symptoms, physical signs, durations, dosages, numerical facts, formulas, or any technical detail that is required to answer the underlying task. Vague placeholders such as "based on the given details", "based on her symptoms", "given the provided information" are forbidden — the rewrite must itself carry those details.
- Maintain the user's position as the information seeker. Do not adopt the assistant's perspective and do not answer, hint at, or evaluate any answer option.
- For multiple-choice questions: DISCARD the answer options (A/B/C/D, a/b/c/d, …). Never include the options in the rewrite, and never reveal or imply which option is correct.
- For "which of the following are true" style questions, rewrite as an open question that asks the external source to state the actual facts about each candidate item, without exposing the option labels or the expected correct combination.
- Output only the rewritten query. No explanations, no justifications, no meta-commentary, no extra text.

## Examples

Original: "Can you suggest a birthday gift for my sister Sarah who loves painting and just moved to Paris?"
Output: "Can you suggest a birthday gift for someone who enjoys painting?"

Original: "Looking for advice on managing my diabetes. I take Metformin twice daily and my sister suggested trying a keto diet."
Output: "Looking for advice on managing diabetes and considering dietary changes."

Original: "John Doe is a 70-year-old male with synthetic chart ID 123456 who presents to the emergency department with pain in epigastrium and difficulty in breathing for 6 hours. On examination, his chest examination was normal. The patient has been taking omeprazole for gastroesophageal reflux disease for the last 6 months. What should be the initial investigation:
A. An ECG
B. An upper GI endoscopy
C. Urgent ultrasound of the abdomen
D. An x-ray chest"
Output: "In an older adult male presenting to the emergency department with epigastric pain and difficulty in breathing for 6 hours and a normal chest examination, what is the most appropriate initial investigation to perform first?"
"""

def load_system_prompt(path: str | None) -> str | None:
    """从外部文件加载 system prompt；若未提供则返回内置默认值。"""
    if path is None:
        return DEFAULT_SYSTEM_PROMPT
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"system prompt file not found: {p}")
    text = p.read_text(encoding="utf-8").strip()
    return text or None


def read_jsonl(path: str):
    """逐行读 jsonl 并返回 list[dict]。"""
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"invalid json at line {line_no} of {path}: {e}") from e
    return items


def _extract_origin_ea(spec: dict) -> tuple[list[str], list[dict]]:
    """从 spec.essential_info 中抽取人工标注的 essential 信息。

    返回:
        origin_ea:      list[str]，仅取每个元素的 value，与 judge 抽到的 ea 同构
        origin_ea_full: list[dict]，保留 {"attribute", "value"} 原结构
    """
    raw = spec.get("essential_info", []) or []
    origin_ea: list[str] = []
    origin_ea_full: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        value = item.get("value")
        attribute = item.get("attribute")
        if value is None:
            continue
        origin_ea.append(str(value))
        origin_ea_full.append(
            {
                "attribute": "" if attribute is None else str(attribute),
                "value": str(value),
            }
        )
    return origin_ea, origin_ea_full


def make_record(example: dict, idx: int, split: str, system_prompt: str | None) -> dict:
    raw_prompt = example.get("raw_prompt", "")
    gold = example.get("gold_reformulation", "")

    judge_out = example.get("judge_out", {}) or {}
    ea = judge_out.get("essential_attributes", []) or []
    ne = judge_out.get("nonessential_attributes", []) or []

    spec = example.get("spec", {}) or {}
    origin_ea, origin_ea_full = _extract_origin_ea(spec)
    essential_policy = spec.get("essential_policy", "")

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": raw_prompt})

    return {
        "data_source": "priv",
        "prompt": messages,
        "ability": "privacy",
        "reward_model": {
            "style": "rule",
            "ground_truth": gold,
        },
        "extra_info": {
            "split": split,
            "index": idx,
            "answer": gold,
            "question": raw_prompt,
            "ea": [str(x) for x in ea],
            "ne": [str(x) for x in ne],
            "origin_ea": origin_ea,
            "essential_policy": "" if essential_policy is None else str(essential_policy),
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_path",
        default="/media/sysu/computer2/hxy/verl_old/data/priv/smoke_518.jsonl",
        help="输入的 jsonl 路径",
    )
    parser.add_argument(
        "--local_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/priv_518",
        help="parquet 输出目录",
    )
    parser.add_argument(
        "--system_prompt_file",
        default=None,
        help="可选，从该文件读取 system prompt；不传则使用内置默认 prompt。",
    )
    parser.add_argument(
        "--no_system_prompt",
        action="store_true",
        help="若设置则不在 prompt 中插入 system 消息，仅保留 user 消息。",
    )
    parser.add_argument(
        "--test_size",
        type=int,
        default=1000,
        help="切分到 test.parquet 的样本数量，默认 0 表示全部进 train。",
    )
    parser.add_argument(
        "--shuffle_seed",
        type=int,
        default=None,
        help="若给定则在切分前用此 seed 进行 shuffle。",
    )
    parser.add_argument("--hdfs_dir", default=None)
    args = parser.parse_args()

    system_prompt = None if args.no_system_prompt else load_system_prompt(args.system_prompt_file)

    raw_items = read_jsonl(args.input_path)
    if args.shuffle_seed is not None:
        import random

        rng = random.Random(args.shuffle_seed)
        rng.shuffle(raw_items)

    if args.test_size > 0:
        assert args.test_size < len(raw_items), (
            f"test_size={args.test_size} >= total={len(raw_items)}"
        )
        train_items = raw_items[: -args.test_size]
        test_items = raw_items[-args.test_size :]
    else:
        train_items = raw_items
        test_items = []

    train_records = [
        make_record(ex, idx, "train", system_prompt) for idx, ex in enumerate(train_items)
    ]
    test_records = [
        make_record(ex, idx, "test", system_prompt) for idx, ex in enumerate(test_items)
    ]

    os.makedirs(args.local_dir, exist_ok=True)

    train_ds = datasets.Dataset.from_list(train_records)
    train_path = os.path.join(args.local_dir, "train.parquet")
    train_ds.to_parquet(train_path)
    print(f"[priv] wrote {len(train_ds)} train samples -> {train_path}")

    if test_records:
        test_ds = datasets.Dataset.from_list(test_records)
        test_path = os.path.join(args.local_dir, "test.parquet")
        test_ds.to_parquet(test_path)
        print(f"[priv] wrote {len(test_ds)} test  samples -> {test_path}")

    if args.hdfs_dir is not None:
        makedirs(args.hdfs_dir)
        copy(src=args.local_dir, dst=args.hdfs_dir)


if __name__ == "__main__":
    main()
