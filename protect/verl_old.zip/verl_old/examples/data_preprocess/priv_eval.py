# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Preprocess the priv evaluation set (e.g. 510eval/06_ea_na_A.jsonl) to parquet.

输入: 一个 jsonl 文件，每行一个评测样本（参考 510eval/06_ea_na_A (1).jsonl）。
       样本中关键字段：
         - first_user        : 用户的原始 prompt（作为 question）
         - primary_context   : 主任务相关的核心上下文（list[str]）
         - ea                : essential attributes（list[str]）
         - na                : nonessential attributes（list[str]）

输出: 默认在 --local_dir 下生成 test.parquet（评测集没有 gold，不切 train）。

字段映射约定（与 priv.py 保持一致，便于复用同一份训练/推理 pipeline）:
    data_source                     -> "priv"
    prompt                          -> [system?, user(first_user)]
    ability                         -> "privacy"
    reward_model.style              -> "rule"
    reward_model.ground_truth       -> ""  (评测集无 gold)
    extra_info.split                -> "test"（默认）
    extra_info.index                -> 行号 idx
    extra_info.question             -> first_user
    extra_info.answer               -> ""  (评测集无 gold)
    extra_info.primary_context      -> 原样本 primary_context (list[str])
    extra_info.ea                   -> 原样本 ea (list[str])
    extra_info.ne                   -> 原样本 na (list[str])，沿用 priv.py 中 "ne" 命名
"""

import argparse
import json
import os
from pathlib import Path

import datasets

from verl.utils.hdfs_io import copy, makedirs


DEFAULT_SYSTEM_PROMPT = """
You are a privacy-conscious assistant that rewrites a user's request into an information-seeking query that can be safely sent to an external knowledge source (e.g. a stronger LLM or a search engine). The rewritten query will be used to retrieve background knowledge that the user will then combine with the original request to produce the final answer locally. The rewrite therefore does NOT need to mirror the original surface form (e.g. it does not need to remain a multiple-choice question); it only needs to be a clean information request that returns the knowledge required to solve the underlying task.

The rewrite must:
- Remove every direct identifier, real or synthetic: personal names, patient / chart / record IDs, addresses, phone numbers, dates of birth, account numbers, etc.
- Remove or generalize information that is not needed to solve the underlying task (unrelated personal details, narrative framing, irrelevant social context).
- KEEP every piece of task-relevant information VERBATIM, except for age information, which should be generalized as described above. Do not paraphrase clinical findings, lab values, symptoms, physical signs, durations, dosages, numerical facts, formulas, or any technical detail that is required to answer the underlying task. Vague placeholders such as "based on the given details", "based on her symptoms", "given the provided information" are forbidden — the rewrite must itself carry those details.
- Maintain the user's position as the information seeker. Do not adopt the assistant's perspective and do not answer, hint at, or evaluate any answer option.
- For multiple-choice questions: DISCARD the answer options (A/B/C/D, a/b/c/d, …). Never include the options in the rewrite, and never reveal or imply which option is correct.
- For "which of the following are true" style questions, rewrite as an open question that asks the external source to state the actual facts about each candidate item, without exposing the option labels or the expected correct combination.
- Output only the rewritten query. No explanations, no justifications, no meta-commentary, no extra text.

## Examples

Original: "Can you suggest a birthday gift for my sister Sarah who loves painting and just moved to Paris?"
Output: "Can you suggest a birthday gift for someone who enjoys painting?"

Original: "Looking for advice on managing my diabetes. I take Metformin twice daily and my sister suggested trying a keto diet."
Output: "Looking for advice on managing diabetes and considering dietary changes."

Original: "John Doe is a 70-year-old male with synthetic chart ID 123456 who presents to the emergency department with pain in epigastrium and difficulty in breathing for 6 hours. On examination, his chest examination was normal. The patient has been taking omeprazole for gastroesophageal reflux disease for the last 6 months. What should be the initial investigation:
A. An ECG
B. An upper GI endoscopy
C. Urgent ultrasound of the abdomen
D. An x-ray chest"
Output: "In an older adult male presenting to the emergency department with epigastric pain and difficulty in breathing for 6 hours and a normal chest examination, what is the most appropriate initial investigation to perform first?"
"""


def load_system_prompt(path: str | None) -> str | None:
    """从外部文件加载 system prompt；若未提供则返回内置默认值。"""
    if path is None:
        return DEFAULT_SYSTEM_PROMPT
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"system prompt file not found: {p}")
    text = p.read_text(encoding="utf-8").strip()
    return text or None


def read_jsonl(path: str):
    """逐行读 jsonl 并返回 list[dict]。"""
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"invalid json at line {line_no} of {path}: {e}") from e
    return items


def _to_str_list(value) -> list[str]:
    """把可能为 None / 非 list 的字段安全转成 list[str]。"""
    if value is None:
        return []
    if not isinstance(value, list):
        return [str(value)]
    return [str(x) for x in value if x is not None]


def make_record(example: dict, idx: int, split: str, system_prompt: str | None) -> dict:
    question = example.get("first_user", "") or ""

    primary_context = _to_str_list(example.get("primary_context"))
    ea = _to_str_list(example.get("ea"))
    ne = _to_str_list(example.get("na"))

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": question})

    return {
        "data_source": "priv",
        "prompt": messages,
        "ability": "privacy",
        "reward_model": {
            "style": "rule",
            "ground_truth": "",
        },
        "extra_info": {
            "split": split,
            "index": idx,
            "question": question,
            "answer": "",
            "primary_context": primary_context,
            "ea": ea,
            "ne": ne,
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_path",
        default="/media/sysu/computer2/hxy/verl_old/510eval/03_ea_na_A.jsonl",
        help="输入的 jsonl 路径",
    )
    parser.add_argument(
        "--local_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/wildchat",
        help="parquet 输出目录",
    )
    parser.add_argument(
        "--output_name",
        default="03_ea_na_A.parquet",
        help="输出 parquet 文件名（评测集默认走 test.parquet）。",
    )
    parser.add_argument(
        "--split",
        default="test",
        help="写入 extra_info.split 的字段值，默认 test。",
    )
    parser.add_argument(
        "--system_prompt_file",
        default=None,
        help="可选，从该文件读取 system prompt；不传则使用内置默认 prompt。",
    )
    parser.add_argument(
        "--no_system_prompt",
        action="store_true",
        help="若设置则不在 prompt 中插入 system 消息，仅保留 user 消息。",
    )
    parser.add_argument("--hdfs_dir", default=None)
    args = parser.parse_args()

    system_prompt = None if args.no_system_prompt else load_system_prompt(args.system_prompt_file)

    raw_items = read_jsonl(args.input_path)
    records = [
        make_record(ex, idx, args.split, system_prompt) for idx, ex in enumerate(raw_items)
    ]

    os.makedirs(args.local_dir, exist_ok=True)
    out_path = os.path.join(args.local_dir, args.output_name)
    ds = datasets.Dataset.from_list(records)
    ds.to_parquet(out_path)
    print(f"[priv_eval] wrote {len(ds)} samples -> {out_path}")

    if args.hdfs_dir is not None:
        makedirs(args.hdfs_dir)
        copy(src=args.local_dir, dst=args.hdfs_dir)


if __name__ == "__main__":
    main()
