# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Preprocess the med (medical Q&A) dataset to parquet format for verl.

输入: 一个 jsonl 文件，每行一个样本（参考 data/med/med.jsonl）。
输出: 在 --local_dir 下生成 med.parquet（全部归为 test，无 train 切分）。

字段映射约定（与 data/gsm8k/data_read.md 中的指引保持一致，参见 data/med/skills.md）:
    data_source                     -> "priv"
    prompt                          -> [system?, user(Syn_Question)]
    ability                         -> "Med"
    reward_model.style              -> "rule"
    reward_model.ground_truth       -> Response
    extra_info.answer               -> Response
    extra_info.question             -> Syn_Question
    extra_info.split                -> "test"
    extra_info.index                -> 行号 idx
    extra_info.key_spans            -> label.key_spans
    extra_info.excluded_information -> label.excluded_information
    extra_info.answer_summary       -> label.answer_summary
"""

import argparse
import json
import os
from pathlib import Path

import datasets

from verl.utils.hdfs_io import copy, makedirs

DEFAULT_SYSTEM_PROMPT = """
You are a privacy-conscious assistant that rewrites a user's request into an information-seeking query that can be safely sent to an external knowledge source (e.g. a stronger LLM or a search engine). The rewritten query will be used to retrieve background knowledge that the user will then combine with the original request to produce the final answer locally. The rewrite therefore does NOT need to mirror the original surface form (e.g. it does not need to remain a multiple-choice question); it only needs to be a clean information request that returns the knowledge required to solve the underlying task.

The rewrite must:
- Remove every direct identifier, real or synthetic: personal names, patient / chart / record IDs, addresses, phone numbers, dates of birth, account numbers, etc.
- Remove or generalize information that is not needed to solve the underlying task (unrelated personal details, narrative framing, irrelevant social context).
- KEEP every piece of task-relevant information VERBATIM, except for age information, which should be generalized as described above. Do not paraphrase clinical findings, lab values, symptoms, physical signs, durations, dosages, numerical facts, formulas, or any technical detail that is required to answer the underlying task. Vague placeholders such as "based on the given details", "based on her symptoms", "given the provided information" are forbidden — the rewrite must itself carry those details.
- Maintain the user's position as the information seeker. Do not adopt the assistant's perspective and do not answer, hint at, or evaluate any answer option.
- For multiple-choice questions: DISCARD the answer options (A/B/C/D, a/b/c/d, …). Never include the options in the rewrite, and never reveal or imply which option is correct.
- For "which of the following are true" style questions, rewrite as an open question that asks the external source to state the actual facts about each candidate item, without exposing the option labels or the expected correct combination.
- Output only the rewritten query. No explanations, no justifications, no meta-commentary, no extra text.

## Examples

Original: "Can you suggest a birthday gift for my sister Sarah who loves painting and just moved to Paris?"
Output: "Can you suggest a birthday gift for someone who enjoys painting?"

Original: "Looking for advice on managing my diabetes. I take Metformin twice daily and my sister suggested trying a keto diet."
Output: "Looking for advice on managing diabetes and considering dietary changes."

Original: "John Doe is a 70-year-old male with synthetic chart ID 123456 who presents to the emergency department with pain in epigastrium and difficulty in breathing for 6 hours. On examination, his chest examination was normal. The patient has been taking omeprazole for gastroesophageal reflux disease for the last 6 months. What should be the initial investigation:
A. An ECG
B. An upper GI endoscopy
C. Urgent ultrasound of the abdomen
D. An x-ray chest"
Output: "In an older adult male presenting to the emergency department with epigastric pain and difficulty in breathing for 6 hours and a normal chest examination, what is the most appropriate initial investigation to perform first?"
"""

def load_system_prompt(path: str | None) -> str | None:
    """从外部文件加载 system prompt；若未提供则返回内置默认值。"""
    if path is None:
        return DEFAULT_SYSTEM_PROMPT
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"system prompt file not found: {p}")
    text = p.read_text(encoding="utf-8").strip()
    return text or None


def read_jsonl(path: str):
    """逐行读 jsonl 并返回 list[dict]。"""
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"invalid json at line {line_no} of {path}: {e}") from e
    return items


def _normalize_key_spans(raw) -> list[dict]:
    """统一 key_spans 结构为 list[{"span": str, "reason": str}]，保证 parquet schema 一致。"""
    out: list[dict] = []
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        span = item.get("span")
        reason = item.get("reason")
        if span is None:
            continue
        out.append(
            {
                "span": str(span),
                "reason": "" if reason is None else str(reason),
            }
        )
    return out


def _normalize_excluded_information(raw) -> list[dict]:
    """统一 excluded_information 结构为 list[{"text": str, "reason": str}]。"""
    out: list[dict] = []
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        text = item.get("text")
        reason = item.get("reason")
        if text is None:
            continue
        out.append(
            {
                "text": str(text),
                "reason": "" if reason is None else str(reason),
            }
        )
    return out


def make_record(example: dict, idx: int, split: str, system_prompt: str | None) -> dict:
    syn_question = example.get("Syn_Question", "") or ""
    response = example.get("Response", "") or ""

    label = example.get("label", {}) or {}
    key_spans = _normalize_key_spans(label.get("key_spans"))
    excluded_information = _normalize_excluded_information(label.get("excluded_information"))
    answer_summary = label.get("answer_summary", "") or ""

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": syn_question})

    return {
        "data_source": "priv",
        "prompt": messages,
        "ability": "Med",
        "reward_model": {
            "style": "rule",
            "ground_truth": response,
        },
        "extra_info": {
            "split": split,
            "index": idx,
            "answer": response,
            "question": syn_question,
            "key_spans": key_spans,
            "excluded_information": excluded_information,
            "answer_summary": str(answer_summary),
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_path",
        default="/media/sysu/computer2/hxy/verl_old/data/med/med2.jsonl",
        help="输入的 jsonl 路径",
    )
    parser.add_argument(
        "--local_dir",
        default="/media/sysu/computer2/hxy/verl_old/data/med",
        help="parquet 输出目录",
    )
    parser.add_argument(
        "--output_name",
        default="med2.parquet",
        help="输出 parquet 文件名（默认 med.parquet）",
    )
    parser.add_argument(
        "--system_prompt_file",
        default=None,
        help="可选，从该文件读取 system prompt；不传则不插入 system 消息。",
    )
    parser.add_argument("--hdfs_dir", default=None)
    args = parser.parse_args()

    system_prompt = load_system_prompt(args.system_prompt_file)

    raw_items = read_jsonl(args.input_path)

    records = [
        make_record(ex, idx, "test", system_prompt) for idx, ex in enumerate(raw_items)
    ]

    os.makedirs(args.local_dir, exist_ok=True)

    ds = datasets.Dataset.from_list(records)
    out_path = os.path.join(args.local_dir, args.output_name)
    ds.to_parquet(out_path)
    print(f"[med] wrote {len(ds)} test samples -> {out_path}")

    if args.hdfs_dir is not None:
        makedirs(args.hdfs_dir)
        copy(src=args.local_dir, dst=args.hdfs_dir)


if __name__ == "__main__":
    main()
