# 目标：
评测测试集的隐私泄露率，由于priv_query是暴露给远端不受信任llm的唯一信息端口，即唯一可能隐私泄露源头，因此我们的隐私泄露率主要基于priv_query去计算。

## 输入
使用训练好的模型，对测试集question进行改写得到priv_query字段。
input_file:/media/sysu/computer2/hxy/verl_old/data/priv/test_with_priv_query.parquet
## 输出
隐私泄露率

## 如何衡量隐私的泄露呢？
1. 参考训练时reward的计算逻辑
/media/sysu/computer2/hxy/verl_old/verl/utils/reward_score/priv.py
可以用Jaccard算或者用BERTScore？哪个更具说服力呢？是算泄露样本占总样本的比例？还是算其他的一些数值？
2. 也计算pii的泄露率，感觉这样更有说服力？


