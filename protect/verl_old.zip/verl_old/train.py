"""
GPU 显存占用脚本
用途: 占用指定 GPU (默认 1, 2 号卡) 的显存与少量算力, 避免被其他任务抢占
用法:
    python train.py                       # 默认占用 GPU 1,2, 每卡 70GB
    python train.py --gpus 1,2 --mem 70   # 指定 GPU 与每卡显存 (GB)
    python train.py --gpus 1,2 --ratio 0.9  # 按比例占用 (0~1)
    python train.py --no-compute          # 仅占显存, 不跑算力 (利用率会显示 0%)

说明:
- A100 80GB 单卡建议 --mem 70 (留 ~10GB 给系统/驱动开销, 防止 OOM)
- 默认会跑一个轻量矩阵乘法循环, 让 nvidia-smi 显示利用率, 防止被 "空闲回收" 类调度器抢占
- Ctrl+C 可安全退出, 显存会自动释放
"""

import argparse
import os
import sys
import time

# 必须在 import torch 之前设置 (这里我们用 torch 自己的 device 选择, 不再用 CUDA_VISIBLE_DEVICES)
import torch


def parse_args():
    parser = argparse.ArgumentParser(description="GPU memory holder")
    parser.add_argument("--gpus", type=str, default="1,2",
                        help="要占用的 GPU id, 逗号分隔, 如 '1,2'")
    parser.add_argument("--mem", type=float, default=70.0,
                        help="每张卡占用的显存大小 (GB), 与 --ratio 二选一")
    parser.add_argument("--ratio", type=float, default=None,
                        help="按总显存比例占用 (0~1), 设置后覆盖 --mem")
    parser.add_argument("--block-mb", type=int, default=512,
                        help="每个张量块大小 (MB), 用多块拼接到目标显存, 防一次性大块 OOM")
    parser.add_argument("--no-compute", action="store_true",
                        help="只占显存, 不跑算力循环")
    parser.add_argument("--compute-size", type=int, default=4096,
                        help="算力循环中的方阵边长 (越大算力占用越高)")
    parser.add_argument("--interval", type=float, default=0.05,
                        help="算力循环每次迭代间隔秒数 (越小利用率越高)")
    return parser.parse_args()


def allocate_on_gpu(gpu_id: int, target_gb: float, block_mb: int):
    """在指定 GPU 上分配 target_gb 显存, 返回持有的张量列表."""
    device = torch.device(f"cuda:{gpu_id}")
    torch.cuda.set_device(device)

    total_bytes = int(target_gb * (1024 ** 3))
    block_bytes = int(block_mb * (1024 ** 2))
    # float32 = 4 bytes
    block_numel = block_bytes // 4

    holders = []
    allocated = 0
    while allocated + block_bytes <= total_bytes:
        try:
            t = torch.empty(block_numel, dtype=torch.float32, device=device)
            # 写一下, 强制真的分配 (避免 lazy alloc)
            t.fill_(0.0)
            holders.append(t)
            allocated += block_bytes
        except RuntimeError as e:
            print(f"[GPU {gpu_id}] 分配到 {allocated / (1024**3):.2f} GB 时 OOM: {e}",
                  file=sys.stderr)
            break

    # 尝试再补一个小尾块
    remain = total_bytes - allocated
    if remain > 64 * 1024 * 1024:  # >64MB 才补
        try:
            tail_numel = remain // 4
            t = torch.empty(tail_numel, dtype=torch.float32, device=device)
            t.fill_(0.0)
            holders.append(t)
            allocated += remain
        except RuntimeError:
            pass

    print(f"[GPU {gpu_id}] 已占用显存: {allocated / (1024**3):.2f} GB "
          f"({len(holders)} 块)")
    return holders, device


def main():
    args = parse_args()

    if not torch.cuda.is_available():
        print("CUDA 不可用, 退出.", file=sys.stderr)
        sys.exit(1)

    gpu_ids = [int(x) for x in args.gpus.split(",") if x.strip() != ""]
    n_dev = torch.cuda.device_count()
    for g in gpu_ids:
        if g < 0 or g >= n_dev:
            print(f"GPU id {g} 越界 (本机共 {n_dev} 张卡)", file=sys.stderr)
            sys.exit(1)

    print(f"目标 GPU: {gpu_ids}, 本机可见 GPU 数: {n_dev}")
    print(f"当前进程 PID: {os.getpid()}")

    # 计算每卡目标显存
    holders_per_gpu = []
    devices = []
    for g in gpu_ids:
        props = torch.cuda.get_device_properties(g)
        total_gb = props.total_memory / (1024 ** 3)
        if args.ratio is not None:
            target_gb = total_gb * args.ratio
        else:
            target_gb = args.mem
        target_gb = min(target_gb, total_gb - 1.0)  # 至少留 1GB
        print(f"[GPU {g}] {props.name}, 总显存 {total_gb:.1f} GB, "
              f"准备占用 {target_gb:.1f} GB")

        holders, device = allocate_on_gpu(g, target_gb, args.block_mb)
        holders_per_gpu.append(holders)
        devices.append(device)

    print("显存占用完成. " +
          ("仅占显存模式." if args.no_compute else "进入算力循环 (Ctrl+C 退出)..."))

    # 算力循环: 在每张卡上各放一对小矩阵, 持续做 matmul, 让 util > 0
    if not args.no_compute:
        compute_tensors = []
        for device in devices:
            a = torch.randn(args.compute_size, args.compute_size, device=device)
            b = torch.randn(args.compute_size, args.compute_size, device=device)
            compute_tensors.append((a, b))

        try:
            step = 0
            while True:
                for (a, b) in compute_tensors:
                    c = a @ b
                    # 防止编译器优化掉
                    a.add_(c, alpha=1e-8)
                torch.cuda.synchronize()
                step += 1
                if step % 200 == 0:
                    print(f"[heartbeat] step={step}")
                if args.interval > 0:
                    time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n收到 Ctrl+C, 退出并释放显存.")
    else:
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            print("\n收到 Ctrl+C, 退出并释放显存.")


if __name__ == "__main__":
    main()

#python train.py --gpus 0,1 --ratio 0.8
