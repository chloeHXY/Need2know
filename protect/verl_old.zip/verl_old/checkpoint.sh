python scripts/model_merger.py merge \
  --backend fsdp \
  --local_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_800/global_step_500/actor \
  --target_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_800/global_step_500/actor_hf

python scripts/model_merger.py merge \
  --backend fsdp \
  --local_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_1100/global_step_200/actor \
  --target_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_1100/global_step_200/actor_hf


python scripts/model_merger.py merge \
  --backend fsdp \
  --local_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_1100/global_step_200/actor \
  --target_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_1100/global_step_200/actor_hf


python scripts/model_merger.py merge \
  --backend fsdp \
  --local_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_ablate_no_R_priv/global_step_300/actor \
  --target_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_ablate_no_R_priv/global_step_300/actor_hf

python scripts/model_merger.py merge \
  --backend fsdp \
  --local_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_ablate_no_utility/global_step_200/actor \
  --target_dir /media/sysu/computer2/hxy/verl_old/checkpoints/verl_grpo_priv_3b/qwen2.5_3b_grpo_priv_ablate_no_utility/global_step_200/actor_hf