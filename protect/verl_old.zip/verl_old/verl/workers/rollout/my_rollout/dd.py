from verl.workers.rollout.base import BaseRollout
import sglang.srt.entrypoints.engine
import torch
# from __future__ import annotations

import asyncio
import logging
import multiprocessing as mp
import os
import time
from contextlib import contextmanager
from copy import deepcopy
from json import JSONDecodeError
from typing import List, Optional, Tuple
from uuid import uuid4
from verl import DataProto
# because chatCompletion is an async method, it makes the whole ray actor be an async actor
# which can not call loop.run_until_complete. So we need to make the engine to be an async class
class AsyncEngine(sglang.srt.entrypoints.engine.Engine):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # default to use dummy load format, which need to reload weights in first time
        self._need_reload = True

    async def release_memory_occupation(self):
        """Release GPU occupation temporarily."""
        obj = ReleaseMemoryOccupationReqInput()
        return await self.tokenizer_manager.release_memory_occupation(obj, None)

    async def resume_memory_occupation(self):
        """Resume GPU occupation."""

        # because __init__ is a sync method, it can not call the async release_memory_occupation
        # have to move release_memory_occupation from __init__ to here
        if self._need_reload:
            await self.release_memory_occupation()
            self._need_reload = False

        obj = ResumeMemoryOccupationReqInput()
        return await self.tokenizer_manager.resume_memory_occupation(obj, None)

    async def update_weights_from_tensor(
        self,
        named_tensors: List[Tuple[str, torch.Tensor]],  # noqa: UP006
        load_format: Optional[str] = None,
        flush_cache: bool = True,
    ):
        """Update weights from distributed source. If there are going to be more updates, set `flush_cache` to be false
        to avoid duplicated cache cleaning operation."""
        obj = UpdateWeightsFromTensorReqInput(
            serialized_named_tensors=[MultiprocessingSerializer.serialize(named_tensors) for _ in range(self.server_args.tp_size)],
            load_format=load_format,
            flush_cache=flush_cache,
        )
        return await self.tokenizer_manager.update_weights_from_tensor(obj, None)

    async def flush_cache(self):
        return await self.tokenizer_manager.flush_cache()

class SimpleSGLangRollout(BaseRollout):
    def __init__(self, model_path, config, tokenizer, model_hf_config):
        """最小化版本，只保留核心功能"""
        self.config = config
        self.tokenizer = tokenizer
        self.pad_token_id = tokenizer.pad_token_id
        
        # 1. 初始化推理引擎
        self._engine = self._init_engine(model_path, config)
        
        # 2. 初始化采样参数'
        self.sampling_params = self._init_sampling_params(config)
    
    def _init_engine(self, model_path, config):
        """初始化 SGLang 引擎"""
        
        engine = AsyncEngine(
            model_path=model_path,
            dtype=config.dtype,
            mem_fraction_static=config.gpu_memory_utilization,
            tp_size=config.tensor_model_parallel_size,
            # 其他基础参数...
        )
        return engine
    
    def _init_sampling_params(self, config):
        """初始化采样参数"""
        return {
            "temperature": config.temperature,
            "top_p": config.top_p,
            "max_new_tokens": config.response_length,
        }
    
    @torch.no_grad()
    def generate_sequences(self, prompts: DataProto, **kwargs) -> DataProto:
        """核心生成方法"""
        # Step 1: 提取输入
        input_ids = prompts.batch["input_ids"]  # (bs, prompt_len)
        attention_mask = prompts.batch["attention_mask"]
        batch_size = input_ids.size(0)
        
        # Step 2: 预处理 - 去除 padding
        prompt_ids_list = []
        for i in range(batch_size):
            # 移除左侧 padding
            valid_tokens = input_ids[i][attention_mask[i] == 1]
            prompt_ids_list.append(valid_tokens.tolist())
        
        # Step 3: 调用引擎生成
        outputs = asyncio.run(self._generate_async(prompt_ids_list))
        
        # Step 4: 后处理 - 拼接 prompt + response
        responses = self._post_process(outputs, input_ids, attention_mask)
        
        return responses
    
    async def _generate_async(self, prompt_ids_list):
        """异步生成调用"""
        return await self._engine.async_generate(
            input_ids=prompt_ids_list,
            sampling_params=self.sampling_params,
        )
    
    def _post_process(self, outputs, original_prompts, attention_mask):
        """后处理：拼接结果"""
        # 这里需要将生成的 tokens 拼接到原始 prompts 上
        # 并更新 attention_mask, position_ids 等
        # ... 实现细节
        pass

    def _test_generation(self):
        """测试生成功能"""
        # 构造测试数据
        tensors = {
            'input_ids': torch.tensor([[1, 2, 3], [4, 5, 6]]),  # shape: [2, 3]
            'attention_mask': torch.tensor([[1, 1, 1], [1, 1, 0]]),  # shape: [2, 3]
        }
        data = DataProto.from_dict(tensors=tensors)
        # test_prompts = DataProto(
        #     batch={
        #         "input_ids": torch.tensor([[1, 2, 3, 4, 5]], dtype=torch.long),
        #         "attention_mask": torch.tensor([[1, 1, 1, 1, 1]], dtype=torch.long),
        #         "batch_size": [1]
        #     },
        #     meta={"num_batches": 1, "sequence_length": 5}
        # )
        
        # 调用生成
        outputs = self.generate_sequences(data)
        
        # 验证输出
        assert "input_ids" in outputs.batch
        assert "responses" in outputs.batch
        # assert outputs.batch["input_ids"].size(0) == 1
        
        print("Test passed!")
        return outputs

if __name__ == "__main__":
    # 简单测试
    import torch
    from dataclasses import dataclass
    path='/media/sysu/computer2/hxy/model_hf/Qwen2.5-0.5B-Instruct'
    from transformers import AutoTokenizer, AutoConfig
    from omegaconf import DictConfig
    
    # 加载 tokenizer 和 config
    tokenizer = AutoTokenizer.from_pretrained(path)
    model_hf_config = AutoConfig.from_pretrained(path)
    
    # 构造配置
    config = DictConfig({
        "dtype": "float16",
        "gpu_memory_utilization": 0.9,
        "tensor_model_parallel_size": 1,
        "temperature": 0.7,
        "top_p": 0.9,
        "response_length": 128,
    })
    
    # 初始化 rollout
    rollout = SimpleSGLangRollout(
        model_path=path,
        config=config,
        tokenizer=tokenizer,
        model_hf_config=model_hf_config
    )
    
    # 测试生成
    outputs = rollout._test_generation()
    print("Generation outputs:", outputs)

    