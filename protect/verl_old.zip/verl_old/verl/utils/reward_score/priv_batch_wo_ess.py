# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Batched reward function for the privacy-reformulation (priv) task.

ABLATION: **w/o R_ess** — 在 ``priv_batch.py`` 基础上去除 utility/essential
奖励项 (R_ess)，用于验证 utility reward 对最终训练效果的贡献。

具体差异 (vs ``priv_batch.py``)：
    - 完全跳过 Step 3 (origin_ea miss-penalty + key_spans 平滑奖励)，
      不再做 utility BERTScore 计算 (节省一次模型前向)。
    - 通过 priv 阶段的样本一律 fall through 到 Step 4 长度爬坡奖励，
      因此 reward 只剩 ``R_priv``：
          * priv 失败 (字面 / 语义任一触发) ⇒ -1.0
          * priv 通过                       ⇒ length_term ∈ (0, 1]

打分逻辑：
    1. 隐私泄露检测 (priv)：基于 ``extra_info["ne"]`` (= C) 与重写后回答 A
       1.1 Jaccard token Coverage(c in A) >= 1.0  → 字面完全覆盖 → return -1
       1.2 BERTScore (rescale_with_baseline=True) 的 P (C→A) 上若 max > 0.3
           → 语义级泄露 → return -1
    2. (Ablated) utility 检查整段跳过：origin_ea / key_spans 信息仍写入
       reward_info 日志便于事后分析，但完全不参与最终 score 计算。
    3. 长度爬坡奖励：通过 priv 后给一个连续的小奖励，避免合格样本之间 score
       完全相同导致没有梯度信号。

接口约定 (BatchRewardManager 兼容)::

    compute_score(
        data_sources:   list[str],
        solution_strs:  list[str],
        ground_truths:  list[str | None],
        extra_infos:    list[dict | None],
        **kwargs,
    ) -> list[dict]

返回 list 长度与输入对齐，每个 dict 必含 ``"score"`` 字段，其他字段为
debug 用 metric。
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Iterable

# ---------------------------------------------------------------------------
# Tokenizer / Jaccard 工具 (与 Demo.ipynb 中的实现保持一致)
# ---------------------------------------------------------------------------
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while", "is", "are", "was", "were",
    "be", "been", "being", "to", "of", "in", "on", "at", "for", "with", "by", "from",
    "as", "that", "this", "these", "those", "it", "its", "i", "me", "my", "we", "our",
    "you", "your", "he", "she", "they", "them", "his", "her", "their",
    "do", "does", "did", "have", "has", "had", "can", "could", "would", "should",
    "will", "shall", "may", "might", "not", "no", "so", "than", "then", "there",
    "some", "any", "all", "more", "most", "much", "many",
}


def _tokenize(text: str) -> list[str]:
    toks = re.findall(r"[a-zA-Z0-9]+", (text or "").lower())
    return [t for t in toks if t not in STOPWORDS]


def jaccard(a: str, b: str) -> float:
    sa, sb = set(_tokenize(a)), set(_tokenize(b))
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def coverage(a: str, b: str) -> float:
    """|tokens(A) ∩ tokens(B)| / |tokens(B)|: B 中有多少比例的词被 A 覆盖。"""
    sa, sb = set(_tokenize(a)), set(_tokenize(b))
    if not sb:
        return 0.0
    return len(sa & sb) / len(sb)


def _filter_ne_by_oea(ne: list[str], oea: list[str]) -> tuple[list[str], list[str]]:
    """从 ne 中去除那些已经在 origin_ea 任一片段中出现过的字符串。

    隐私检测的语义是「答案 A 中是否泄露了原文里不该出现的实体」。若某个 ne
    字符串本身就出现在 origin_ea（用户明确要保留的 essential 片段）中，
    说明它属于 utility 信息，重写答案命中它属于正常行为而非隐私泄露，
    因此在 priv 阶段直接跳过这一项的 coverage / BERTScore 测试。

    匹配规则：忽略大小写、忽略首尾空白的子串匹配。

    Returns:
        (kept_ne, dropped_ne)。``kept_ne`` 用于后续 priv 检测；``dropped_ne``
        仅作为 debug 信息记录。
    """
    if not ne or not oea:
        return list(ne), []
    oea_lower = [e.lower() for e in oea]
    kept: list[str] = []
    dropped: list[str] = []
    for c in ne:
        c_norm = c.strip().lower()
        if c_norm and any(c_norm in eo for eo in oea_lower):
            dropped.append(c)
        else:
            kept.append(c)
    return kept, dropped


# ---------------------------------------------------------------------------
# BERTScorer 单例 (lazy init, 避免每次 reward 都重新加载模型)
# ---------------------------------------------------------------------------
_BERT_SCORER = None
_BERT_LOAD_ERROR: Exception | None = None

DEFAULT_ROBERTA_LARGE_PATH = os.environ.get(
    "PRIV_BERTSCORE_MODEL_PATH",
    "/media/sysu/computer2/hxy/model_hf/models--FacebookAI--roberta-large",
)


def _get_bert_scorer():
    """惰性加载 BERTScorer (rescale_with_baseline=True, roberta-large, en)。

    传入的 model_type 可以是本地路径，但需要手动指定 baseline_path 才能找到
    rescale baseline 文件。
    """
    global _BERT_SCORER, _BERT_LOAD_ERROR
    if _BERT_SCORER is not None or _BERT_LOAD_ERROR is not None:
        return _BERT_SCORER
    try:
        import bert_score

        baseline_path = os.path.join(
            os.path.dirname(bert_score.__file__),
            "rescale_baseline",
            "en",
            "roberta-large.tsv",
        )
        _BERT_SCORER = bert_score.BERTScorer(
            model_type=DEFAULT_ROBERTA_LARGE_PATH,
            num_layers=17,
            lang="en",
            rescale_with_baseline=True,
            baseline_path=baseline_path,
        )
    except Exception as e:
        _BERT_LOAD_ERROR = e
        _BERT_SCORER = None
    return _BERT_SCORER


def _bert_p_pairs(cands: list[str], refs: list[str], batch_size: int = 64) -> list[float] | None:
    """对任意一一对应的 (cand, ref) 对，一次性算出 BERTScore rescaled Precision。

    与 ``priv.py`` 中 ``_bert_p_rescaled(cands, ref)`` 不同，这里 ``refs`` 也
    是一个等长 list，可以来自 batch 中不同样本，从而实现 batch-级合并。

    Args:
        cands: 候选文本列表 (例如所有样本的 ne / origin_ea 片段)
        refs:  对应的参考文本列表 (例如对应样本的回答 A)
        batch_size: 传给 BERTScorer 的 batch_size (内部对模型前向再做切片)

    Returns:
        list[float]，长度 = len(cands)；模型加载失败或输入为空时返回 None。
    """
    assert len(cands) == len(refs), "cands / refs 必须等长"
    scorer = _get_bert_scorer()
    if scorer is None or not cands:
        return None
    try:
        P, _, _ = scorer.score(cands=list(cands), refs=list(refs), batch_size=batch_size)
        return [float(x) for x in P.tolist()]
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 输入清洗
# ---------------------------------------------------------------------------
def _to_str_list(x: Any) -> list[str]:
    """把 list / numpy.ndarray / 其他可迭代对象统一转成 list[str]，过滤空值。"""
    if x is None:
        return []
    if isinstance(x, str):
        return [x] if x else []
    if isinstance(x, Iterable):
        out = []
        for item in x:
            if item is None:
                continue
            s = str(item).strip()
            if s:
                out.append(s)
        return out
    return [str(x)]


# ---------------------------------------------------------------------------
# 主函数 (batch)
# ---------------------------------------------------------------------------
PRIV_BERT_P_THRESHOLD = 0.3
PRIV_COVERAGE_THRESHOLD = 1.0
UTILITY_BERT_P_THRESHOLD = 0.3
UTILITY_COVERAGE_THRESHOLD = 0.5
UTILITY_MISS_PENALTY = -0.2
LENGTH_REWARD_WEIGHT = 1.0
KEY_SPANS_GAMMA = 0.4


def compute_score(
    data_sources: list[str] | None = None,
    solution_strs: list[str] | None = None,
    ground_truths: list[str | None] | None = None,
    extra_infos: list[dict | None] | None = None,
    bert_batch_size: int = 64,
    log_jsonl_path: str | None = "default_rollout_info_priv.jsonl",
    **kwargs: Any,
) -> list[dict]:
    """Batch 版本 priv reward。

    所有 list 参数应等长。BERTScore 计算会跨样本合并到一次模型前向中以加速。

    Args:
        data_sources:   每个样本的 data_source（仅作日志/调试用，不参与打分）
        solution_strs:  模型生成的重写文本 A
        ground_truths:  原始问题/参考文本 (用于 length 奖励)
        extra_infos:    每个样本的 extra_info dict，需要包含
                        ``ne`` (NE 列表) 和 ``origin_ea`` (essential 片段列表)
        bert_batch_size: 传给 BERTScorer 的内部 batch_size
        log_jsonl_path:  若非 None，每个样本会追加一行 JSON 到该路径，
                         与 ``priv.py + __init__.py`` 老路径下的日志格式对齐；
                         置为 None 可禁用。

    Returns:
        list[dict]，长度 = len(solution_strs)；每个 dict 至少包含 ``"score"``
        字段，其余 key 为 debug metric。
    """
    # breakpoint()
    if solution_strs is None:
        return []
    n = len(solution_strs)
    if extra_infos is None:
        extra_infos = [None] * n
    if ground_truths is None:
        ground_truths = [None] * n
    if data_sources is None:
        data_sources = ["priv"] * n
    assert len(extra_infos) == n and len(ground_truths) == n, (
        "solution_strs / extra_infos / ground_truths 长度必须一致"
    )

    # ---------- Step 1: 解析 + 廉价的 coverage 检查 + 空字符串短路 ----------
    parsed: list[dict[str, Any]] = []
    for i in range(n):
        A = solution_strs[i] or ""
        ei = extra_infos[i] or {}
        ne_raw = _to_str_list(ei.get("ne"))
        oea = _to_str_list(ei.get("origin_ea"))
        question = ei.get("question")
        key_spans = _to_str_list(ei.get("key_spans"))
        # 若 ne 项已经出现在 origin_ea 任一片段中，视作 utility 信息，
        # 不再纳入 priv 检测 (coverage + BERTScore 都跳过)。
        ne, ne_skipped = _filter_ne_by_oea(ne_raw, oea)
        gt = ground_truths[i]
        gold = gt if isinstance(gt, str) and gt else str(ei.get("answer", "") or "")

        item: dict[str, Any] = {
            "A": A,
            "ne": ne,
            "oea": oea,
            "key_spans": key_spans,
            "gold": gold,
            "info": {
                "priv_ne_skipped_in_oea": ne_skipped,
                "priv_ne_skipped_count": len(ne_skipped),
            },
            "question": question,
            "score": None,  # None 表示尚未短路，进入下一阶段
        }

        if not A:
            # 没有任何答案直接给最低惩罚，避免空串绕过 priv 检查
            item["score"] = -1.0
            parsed.append(item)
            continue

        # priv：字面 coverage（廉价，可全部样本先做）
        priv_max_cov = 0.0
        priv_argmax_c: str | None = None
        for c in ne:
            cov = coverage(A, c)
            if cov > priv_max_cov:
                priv_max_cov, priv_argmax_c = cov, c
        item["info"]["priv_max_coverage"] = priv_max_cov
        item["info"]["priv_argmax_coverage"] = priv_argmax_c

        if ne and priv_max_cov >= PRIV_COVERAGE_THRESHOLD:
            item["score"] = -1.0

        parsed.append(item)

    # ---------- Step 2: 批量 BERTScore (priv) ----------
    # 收集所有还未短路 & 有 ne 的样本的 (ne_c, A) 对
    priv_cands: list[str] = []
    priv_refs: list[str] = []
    priv_owner: list[tuple[int, int]] = []  # (sample_idx, c_idx)
    for i, p in enumerate(parsed):
        if p["score"] is not None or not p["ne"]:
            continue
        for c_idx, c in enumerate(p["ne"]):
            priv_cands.append(c)
            priv_refs.append(p["A"])
            priv_owner.append((i, c_idx))

    priv_bert = _bert_p_pairs(priv_cands, priv_refs, batch_size=bert_batch_size)

    # 把 priv BERTScore 分发回各样本，并据此做语义泄露短路
    priv_scores_per_sample: dict[int, list[float]] = {i: [] for i in range(n)}
    if priv_bert is not None:
        for k, (i, c_idx) in enumerate(priv_owner):
            # c_idx 与 ne 索引一一对应；这里按顺序 append 即可保留对应关系
            priv_scores_per_sample[i].append(priv_bert[k])

    bert_failed = priv_bert is None and len(priv_cands) > 0
    for i, p in enumerate(parsed):
        if p["score"] is not None:
            continue
        if not p["ne"]:
            continue
        ps = priv_scores_per_sample[i]
        if not ps:
            # bert 加载失败 / 没有调用结果
            if bert_failed:
                print("[priv_batch][error] BERTScore loading error")
                p["info"]["priv_max_p_rescaled"] = None
                if _BERT_LOAD_ERROR is not None:
                    p["info"]["bertscore_error"] = repr(_BERT_LOAD_ERROR)
            continue
        max_p = max(ps)
        argmax_c = p["ne"][ps.index(max_p)]
        p["info"]["priv_max_p_rescaled"] = max_p
        p["info"]["priv_argmax_p_rescaled"] = argmax_c
        if max_p > PRIV_BERT_P_THRESHOLD:
            p["score"] = -1.0

    # ---------- Step 3: utility 检查 (ABLATION: w/o R_ess，已禁用) ----------
    # 本文件是 "w/o R_ess" 消融实验版本：
    #   - 完全跳过 origin_ea miss-penalty 和 key_spans 平滑奖励
    #   - 不再调用 utility BERTScore，节省一次模型前向
    # 所有通过 priv 阶段的样本 (p["score"] is None) 都直接 fall through
    # 到 Step 4 的长度爬坡奖励，因此最终 reward ∈ {-1.0} ∪ (0, 1]：
    #   * priv 失败 → -1.0
    #   * priv 通过 → length_term
    # 仍向 ``p["info"]`` 写入空的 utility / key_spans 占位字段，
    # 保持与 priv_batch.py 的输出字段集合一致，避免 BatchRewardManager
    # 把 reward_extra_info 转 numpy 时形状不齐。
    for i, p in enumerate(parsed):
        if p["score"] is not None:
            continue
        p["info"]["utility_detail"] = []
        p["info"]["utility_miss_count"] = 0
        p["info"]["utility_miss_items"] = []
        p["info"]["key_spans_detail"] = []
        p["info"]["key_spans_hit_count"] = 0
        p["info"]["key_spans_total"] = len(p["key_spans"])
        p["info"]["key_spans_reward"] = 0.0
        p["info"]["key_spans_brevity"] = 0.0
        p["info"]["ablation"] = "wo_R_ess"

    # ---------- Step 4: 长度爬坡奖励 ----------
    for p in parsed:
        if p["score"] is not None:
            continue
        A, gold = p["A"], p["gold"]
        if gold:
            ratio = min(len(A), len(gold)*0.6) / max(len(A), len(gold)*0.6)
        else:
            ratio = 1.0 / (1.0 + abs(len(A) - 100) / 100.0)
        length_term = LENGTH_REWARD_WEIGHT * float(ratio)
        p["info"]["length_term"] = length_term
        p["score"] = length_term

    # ---------- Step 5: 打包返回 + 可选 JSONL 日志 ----------
    # NOTE: 返回到 reward manager 的 dict 只能放标量(float / int / str)，
    # 否则 ray_trainer 里 ``np.array(v)`` 会因为变长 list / 嵌套 dict 触发
    # "inhomogeneous shape" 错误。变长结构(utility_detail / utility_miss_items)
    # 仅写入 JSONL 日志，不进 metrics。
    # 同时确保 *所有样本* 返回同一组 key(缺失值用 0.0 / "" 占位)，否则
    # defaultdict 收集出来的 list 长度会与 batch size 不一致。
    SCALAR_KEYS_DEFAULTS: dict[str, Any] = {
        "priv_max_coverage": 0.0,
        "priv_argmax_coverage": "",
        "priv_max_p_rescaled": 0.0,
        "priv_argmax_p_rescaled": "",
        "priv_ne_skipped_count": 0,
        "utility_miss_count": 0,
        "key_spans_total": 0,
        "key_spans_hit_count": 0,
        "key_spans_reward": 0.0,
        "length_term": 0.0,
    }

    results: list[dict[str, Any]] = []
    log_lines: list[str] | None = [] if log_jsonl_path else None
    for i, p in enumerate(parsed):
        score = float(p["score"])
        out: dict[str, Any] = {"score": score}
        info = p["info"]
        for k, default in SCALAR_KEYS_DEFAULTS.items():
            v = info.get(k, default)
            if v is None:
                v = default
            out[k] = v
        results.append(out)

        if log_lines is not None:
            ei = extra_infos[i] or {}
            log_lines.append(json.dumps({
                "reward_score": score,
                "solution_str": solution_strs[i],
                "ne": ei.get("ne"),
                "origin_ea": ei.get("origin_ea"),
                "key_spans": ei.get("key_spans"),
                "reward_info": info,
                "question": ei.get("question"),
                "ground_truth": ground_truths[i],
                "data_source": data_sources[i],
            }, ensure_ascii=False, default=str))

    if log_lines is not None and log_lines:
        try:
            with open(log_jsonl_path, "a") as f:
                f.write("\n".join(log_lines) + "\n")
        except Exception as e:
            # 日志失败不应影响训练
            print(f"[priv_batch][warn] failed to write {log_jsonl_path}: {e!r}")

    return results


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------
# if __name__ == "__main__":
#     ground_truth = (
#         "My 74-year-old dad, a former police officer in Chicago, is struggling to "
#         "transition into security consulting or training roles. Despite his extensive "
#         "experience, he receives no callbacks. What strategies can help him overcome "
#         "this barrier and secure interviews?"
#     )
#     safe_solution = ground_truth
#     NE = [
#         "dad is absolutely losing his mind",
#         "honestly so am I on his behalf",
#         "watches the Star Wars prequels to decompress",
#         "process is stressing him out",
#     ]
#     origin_ea = ["police officer in Chicago", "74"]
#     extra_info = {"ne": NE, "origin_ea": origin_ea}

#     not_safe_solution = (
#         "My dad is absolutely losing his mind over this and honestly so am I on his "
#         "behalf. He's 74 and spent his whole career as a police officer in Chicago, "
#         "and now that he's looking to transition into something like a security "
#         "consulting or training role, every single application he submits just "
#         "disappears into a void. No callbacks, nothing. We think his age is working "
#         "against him even though he has decades of real experience. He even watches "
#         "the Star Wars prequels to decompress because this process is stressing him "
#         "out so much. What can he actually do to get past this barrier and land "
#         "interviews? Any concrete strategies would help."
#     )
#     samples = [
#         {"solution_str": safe_solution,     "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": not_safe_solution, "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": "",                "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": safe_solution,     "ground_truth": ground_truth, "extra_info": extra_info},
#     ]

#     import time
#     t0 = time.time()
#     out = compute_score(
#         data_sources=["priv"] * len(samples),
#         solution_strs=[s["solution_str"] for s in samples],
#         ground_truths=[s["ground_truth"] for s in samples],
#         extra_infos=[s["extra_info"] for s in samples],
#         log_jsonl_path='zzz.jsonl',  # smoke test 时不要污染日志文件
#     )
#     print(f"batch compute_score elapsed: {time.time() - t0:.2f}s")
#     for i, r in enumerate(out):
#         print(f"--- sample {i} ---")
#         print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
