# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Batched reward function for the privacy-reformulation (priv) task.

ABLATION: **w/o R_priv** — 在 ``priv_batch.py`` 基础上去除整段隐私泄露惩罚项
(R_priv)，用于验证 privacy reward 对最终训练效果的贡献。训练过程中模型变成
"privacy-blind"，仅由 R_ess (utility) 与 length scaffolding 驱动。

具体差异 (vs ``priv_batch.py``)：
    - 不再因 Jaccard coverage(ne, A) >= 1.0 触发 -1 惩罚
      (仍计算并写入 ``priv_max_coverage`` 字段，便于事后做泄露分析)。
    - 完全跳过 Step 2 的 BERTScore(ne → A) 计算，节省一次模型前向；
      ``priv_max_p_rescaled`` 字段写 0.0 占位。
    - **空答案 → -1 这一兜底保留**：不属于 R_priv 语义，是 "不能输出空串"
      的退化保护，移除会让模型很容易 collapse 到空输出。
    - **origin_ea fallback**：若 ``extra_info["origin_ea"]`` (人工标注) 为空，
      回退使用 ``extra_info["ea"]`` (judge 模型抽取的 essential)，从而让更多
      样本走 R_ess 的 miss-penalty 路径而不是直接落到 key_spans / length。
      实际使用的来源会写入 ``info["oea_source"]``: "origin_ea" / "ea_fallback"。

打分逻辑：
    1. (Ablated) priv 字面检测仅作日志记录，不触发 -1。
    2. (Ablated) priv 语义检测完全跳过。
    3. utility 检查 (R_ess) 与 ``priv_batch.py`` 一致：
       3.1 ``origin_ea`` 非空：miss-penalty。
       3.2 ``key_spans`` 非空：(hit/total)^gamma * brevity。
       3.3 两者皆空：走第 4 步长度爬坡。
    4. 长度爬坡奖励：通过前三步后给一个连续的小奖励，避免合格样本之间 score
       完全相同导致没有梯度信号。

最终 reward 取值：
    * 空答案                       → -1.0
    * 其它 (R_priv 完全不参与判定) → R_ess + length term 决定

接口约定 (BatchRewardManager 兼容)::

    compute_score(
        data_sources:   list[str],
        solution_strs:  list[str],
        ground_truths:  list[str | None],
        extra_infos:    list[dict | None],
        **kwargs,
    ) -> list[dict]

返回 list 长度与输入对齐，每个 dict 必含 ``"score"`` 字段，其他字段为
debug 用 metric。
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Iterable

# ---------------------------------------------------------------------------
# Tokenizer / Jaccard 工具 (与 Demo.ipynb 中的实现保持一致)
# ---------------------------------------------------------------------------
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while", "is", "are", "was", "were",
    "be", "been", "being", "to", "of", "in", "on", "at", "for", "with", "by", "from",
    "as", "that", "this", "these", "those", "it", "its", "i", "me", "my", "we", "our",
    "you", "your", "he", "she", "they", "them", "his", "her", "their",
    "do", "does", "did", "have", "has", "had", "can", "could", "would", "should",
    "will", "shall", "may", "might", "not", "no", "so", "than", "then", "there",
    "some", "any", "all", "more", "most", "much", "many",
}


def _tokenize(text: str) -> list[str]:
    toks = re.findall(r"[a-zA-Z0-9]+", (text or "").lower())
    return [t for t in toks if t not in STOPWORDS]


def jaccard(a: str, b: str) -> float:
    sa, sb = set(_tokenize(a)), set(_tokenize(b))
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def coverage(a: str, b: str) -> float:
    """|tokens(A) ∩ tokens(B)| / |tokens(B)|: B 中有多少比例的词被 A 覆盖。"""
    sa, sb = set(_tokenize(a)), set(_tokenize(b))
    if not sb:
        return 0.0
    return len(sa & sb) / len(sb)


def _filter_ne_by_oea(ne: list[str], oea: list[str]) -> tuple[list[str], list[str]]:
    """从 ne 中去除那些已经在 origin_ea 任一片段中出现过的字符串。

    隐私检测的语义是「答案 A 中是否泄露了原文里不该出现的实体」。若某个 ne
    字符串本身就出现在 origin_ea（用户明确要保留的 essential 片段）中，
    说明它属于 utility 信息，重写答案命中它属于正常行为而非隐私泄露，
    因此在 priv 阶段直接跳过这一项的 coverage / BERTScore 测试。

    匹配规则：忽略大小写、忽略首尾空白的子串匹配。

    Returns:
        (kept_ne, dropped_ne)。``kept_ne`` 用于后续 priv 检测；``dropped_ne``
        仅作为 debug 信息记录。
    """
    if not ne or not oea:
        return list(ne), []
    oea_lower = [e.lower() for e in oea]
    kept: list[str] = []
    dropped: list[str] = []
    for c in ne:
        c_norm = c.strip().lower()
        if c_norm and any(c_norm in eo for eo in oea_lower):
            dropped.append(c)
        else:
            kept.append(c)
    return kept, dropped


# ---------------------------------------------------------------------------
# BERTScorer 单例 (lazy init, 避免每次 reward 都重新加载模型)
# ---------------------------------------------------------------------------
_BERT_SCORER = None
_BERT_LOAD_ERROR: Exception | None = None

DEFAULT_ROBERTA_LARGE_PATH = os.environ.get(
    "PRIV_BERTSCORE_MODEL_PATH",
    "/media/sysu/computer2/hxy/model_hf/models--FacebookAI--roberta-large",
)


def _get_bert_scorer():
    """惰性加载 BERTScorer (rescale_with_baseline=True, roberta-large, en)。

    传入的 model_type 可以是本地路径，但需要手动指定 baseline_path 才能找到
    rescale baseline 文件。
    """
    global _BERT_SCORER, _BERT_LOAD_ERROR
    if _BERT_SCORER is not None or _BERT_LOAD_ERROR is not None:
        return _BERT_SCORER
    try:
        import bert_score

        baseline_path = os.path.join(
            os.path.dirname(bert_score.__file__),
            "rescale_baseline",
            "en",
            "roberta-large.tsv",
        )
        _BERT_SCORER = bert_score.BERTScorer(
            model_type=DEFAULT_ROBERTA_LARGE_PATH,
            num_layers=17,
            lang="en",
            rescale_with_baseline=True,
            baseline_path=baseline_path,
        )
    except Exception as e:
        _BERT_LOAD_ERROR = e
        _BERT_SCORER = None
    return _BERT_SCORER


def _bert_p_pairs(cands: list[str], refs: list[str], batch_size: int = 64) -> list[float] | None:
    """对任意一一对应的 (cand, ref) 对，一次性算出 BERTScore rescaled Precision。

    与 ``priv.py`` 中 ``_bert_p_rescaled(cands, ref)`` 不同，这里 ``refs`` 也
    是一个等长 list，可以来自 batch 中不同样本，从而实现 batch-级合并。

    Args:
        cands: 候选文本列表 (例如所有样本的 ne / origin_ea 片段)
        refs:  对应的参考文本列表 (例如对应样本的回答 A)
        batch_size: 传给 BERTScorer 的 batch_size (内部对模型前向再做切片)

    Returns:
        list[float]，长度 = len(cands)；模型加载失败或输入为空时返回 None。
    """
    assert len(cands) == len(refs), "cands / refs 必须等长"
    scorer = _get_bert_scorer()
    if scorer is None or not cands:
        return None
    try:
        P, _, _ = scorer.score(cands=list(cands), refs=list(refs), batch_size=batch_size)
        return [float(x) for x in P.tolist()]
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 输入清洗
# ---------------------------------------------------------------------------
def _to_str_list(x: Any) -> list[str]:
    """把 list / numpy.ndarray / 其他可迭代对象统一转成 list[str]，过滤空值。"""
    if x is None:
        return []
    if isinstance(x, str):
        return [x] if x else []
    if isinstance(x, Iterable):
        out = []
        for item in x:
            if item is None:
                continue
            s = str(item).strip()
            if s:
                out.append(s)
        return out
    return [str(x)]


# ---------------------------------------------------------------------------
# 主函数 (batch)
# ---------------------------------------------------------------------------
PRIV_BERT_P_THRESHOLD = 0.3
PRIV_COVERAGE_THRESHOLD = 1.0
UTILITY_BERT_P_THRESHOLD = 0.3
UTILITY_COVERAGE_THRESHOLD = 0.5
UTILITY_MISS_PENALTY = -0.2
LENGTH_REWARD_WEIGHT = 1.0
KEY_SPANS_GAMMA = 0.4


def compute_score(
    data_sources: list[str] | None = None,
    solution_strs: list[str] | None = None,
    ground_truths: list[str | None] | None = None,
    extra_infos: list[dict | None] | None = None,
    bert_batch_size: int = 64,
    log_jsonl_path: str | None = "default_rollout_info_priv.jsonl",
    **kwargs: Any,
) -> list[dict]:
    """Batch 版本 priv reward。

    所有 list 参数应等长。BERTScore 计算会跨样本合并到一次模型前向中以加速。

    Args:
        data_sources:   每个样本的 data_source（仅作日志/调试用，不参与打分）
        solution_strs:  模型生成的重写文本 A
        ground_truths:  原始问题/参考文本 (用于 length 奖励)
        extra_infos:    每个样本的 extra_info dict，需要包含
                        ``ne`` (NE 列表) 和 ``origin_ea`` (essential 片段列表)
        bert_batch_size: 传给 BERTScorer 的内部 batch_size
        log_jsonl_path:  若非 None，每个样本会追加一行 JSON 到该路径，
                         与 ``priv.py + __init__.py`` 老路径下的日志格式对齐；
                         置为 None 可禁用。

    Returns:
        list[dict]，长度 = len(solution_strs)；每个 dict 至少包含 ``"score"``
        字段，其余 key 为 debug metric。
    """
    # breakpoint()
    if solution_strs is None:
        return []
    n = len(solution_strs)
    if extra_infos is None:
        extra_infos = [None] * n
    if ground_truths is None:
        ground_truths = [None] * n
    if data_sources is None:
        data_sources = ["priv"] * n
    assert len(extra_infos) == n and len(ground_truths) == n, (
        "solution_strs / extra_infos / ground_truths 长度必须一致"
    )

    # ---------- Step 1: 解析 + 廉价的 coverage 检查 + 空字符串短路 ----------
    parsed: list[dict[str, Any]] = []
    for i in range(n):
        A = solution_strs[i] or ""
        ei = extra_infos[i] or {}
        ne_raw = _to_str_list(ei.get("ne"))
        oea = _to_str_list(ei.get("origin_ea"))
        # NOTE(wo_priv only): 若 origin_ea (人工标注的 essential) 为空，
        # 退回到 judge 模型抽出的 ``ea``。这样可以让更多样本走 R_ess 的
        # miss-penalty 路径，而不是直接落到 key_spans / length scaffolding。
        oea_source = "origin_ea"
        if not oea:
            oea = _to_str_list(ei.get("ea"))
            if oea:
                oea_source = "ea_fallback"
        question = ei.get("question")
        key_spans = _to_str_list(ei.get("key_spans"))
        # 若 ne 项已经出现在 oea 任一片段中，视作 utility 信息，
        # 不再纳入 priv 检测 (coverage + BERTScore 都跳过)。
        ne, ne_skipped = _filter_ne_by_oea(ne_raw, oea)
        gt = ground_truths[i]
        gold = gt if isinstance(gt, str) and gt else str(ei.get("answer", "") or "")

        item: dict[str, Any] = {
            "A": A,
            "ne": ne,
            "oea": oea,
            "key_spans": key_spans,
            "gold": gold,
            "info": {
                "priv_ne_skipped_in_oea": ne_skipped,
                "priv_ne_skipped_count": len(ne_skipped),
                "oea_source": oea_source,
            },
            "question": question,
            "score": None,  # None 表示尚未短路，进入下一阶段
        }

        if not A:
            # 没有任何答案直接给最低惩罚，避免空串绕过 priv 检查
            item["score"] = -1.0
            parsed.append(item)
            continue

        # priv：字面 coverage 仅作日志记录 (ABLATION: w/o R_priv，已禁用惩罚)
        priv_max_cov = 0.0
        priv_argmax_c: str | None = None
        for c in ne:
            cov = coverage(A, c)
            if cov > priv_max_cov:
                priv_max_cov, priv_argmax_c = cov, c
        item["info"]["priv_max_coverage"] = priv_max_cov
        item["info"]["priv_argmax_coverage"] = priv_argmax_c
        # NOTE(ablation): priv_max_cov >= 1.0 时本来会 short-circuit 到 -1，
        # 这里直接跳过，让样本继续走 Step 3 (R_ess) / Step 4 (length)。

        parsed.append(item)

    # ---------- Step 2: 批量 BERTScore (priv) (ABLATION: w/o R_priv，已禁用) ----------
    # 本文件是 "w/o R_priv" 消融实验版本，完全跳过 priv 阶段的 BERTScore
    # 调用 (省一次模型前向)。``priv_max_p_rescaled`` 字段写 0.0 占位，
    # 保证 reward_extra_info 的 schema 与原版一致。
    # 若事后需要分析 "无 R_priv 训练后模型语义泄露程度"，可对
    # trajectory jsonl (含 ne / solution_str) 离线再跑一次 BERTScore。
    for i, p in enumerate(parsed):
        p["info"].setdefault("priv_max_p_rescaled", 0.0)
        p["info"].setdefault("priv_argmax_p_rescaled", "")

    # ---------- Step 3: 批量 BERTScore (utility) ----------
    # 只对仍然存活 (priv 通过) 的样本算 utility：
    #   - origin_ea 非空：走 miss-penalty 形式
    #   - origin_ea 为空但 key_spans 非空：走 (hit/total)^gamma 平滑奖励
    util_cands: list[str] = []
    util_refs: list[str] = []
    util_owner: list[tuple[int, int, str]] = []  # (sample_idx, idx, kind)
    for i, p in enumerate(parsed):
        if p["score"] is not None:
            continue
        if p["oea"]:
            for e_idx, ea in enumerate(p["oea"]):
                util_cands.append(ea)
                util_refs.append(p["A"])
                util_owner.append((i, e_idx, "oea"))
        elif p["key_spans"]:
            for e_idx, ks in enumerate(p["key_spans"]):
                util_cands.append(ks)
                util_refs.append(p["A"])
                util_owner.append((i, e_idx, "key_spans"))

    util_bert = _bert_p_pairs(util_cands, util_refs, batch_size=bert_batch_size)
    util_scores_per_sample: dict[int, dict[tuple[str, int], float]] = {i: {} for i in range(n)}
    if util_bert is not None:
        for k, (i, e_idx, kind) in enumerate(util_owner):
            util_scores_per_sample[i][(kind, e_idx)] = util_bert[k]

    for i, p in enumerate(parsed):
        if p["score"] is not None:
            continue

        if p["oea"]:
            bert_for_i = util_scores_per_sample[i]
            miss_items: list[str] = []
            ea_detail: list[dict[str, Any]] = []
            for e_idx, ea_item in enumerate(p["oea"]):
                cov = coverage(p["A"], ea_item)
                p_rs = bert_for_i.get(("oea", e_idx), 0.0)
                hit = (cov >= UTILITY_COVERAGE_THRESHOLD) or (p_rs >= UTILITY_BERT_P_THRESHOLD)
                ea_detail.append({"item": ea_item, "coverage": cov, "p_rescaled": p_rs, "hit": hit})
                if not hit:
                    miss_items.append(ea_item)
            p["info"]["utility_detail"] = ea_detail
            p["info"]["utility_miss_count"] = len(miss_items)
            p["info"]["utility_miss_items"] = miss_items
            if miss_items:
                p["score"] = max(-1.0, len(miss_items) * UTILITY_MISS_PENALTY)
        elif p["key_spans"]:
            bert_for_i = util_scores_per_sample[i]
            hit_count = 0
            ks_detail: list[dict[str, Any]] = []
            for e_idx, ks_item in enumerate(p["key_spans"]):
                cov = coverage(p["A"], ks_item)
                p_rs = bert_for_i.get(("key_spans", e_idx), 0.0)
                hit = (cov >= UTILITY_COVERAGE_THRESHOLD) or (p_rs >= UTILITY_BERT_P_THRESHOLD)
                ks_detail.append({"item": ks_item, "coverage": cov, "p_rescaled": p_rs, "hit": hit})
                if hit:
                    hit_count += 1
            ks_total = len(p["key_spans"])
            ratio = hit_count / ks_total if ks_total > 0 else 0.0
            ks_reward = float(ratio) ** KEY_SPANS_GAMMA
            #避免无限填充文本，从而hack 命中，添加长度惩罚
            brevity = min(1.0, min(len(p["question"])*0.5,len(p["gold"])) / max(len(p["A"]), 1))
            p["info"]["key_spans_detail"] = ks_detail
            p["info"]["key_spans_hit_count"] = hit_count
            p["info"]["key_spans_total"] = ks_total
            p["info"]["key_spans_reward"] = ks_reward
            p["info"]["key_spans_brevity"] = brevity
            # 与 oea 路径保持字段对齐
            p["info"]["utility_detail"] = []
            p["info"]["utility_miss_count"] = 0
            p["info"]["utility_miss_items"] = []
            p["score"] = ks_reward*brevity
        else:
            # 既无 origin_ea 也无 key_spans：保留原有行为，留给长度爬坡奖励
            p["info"]["utility_detail"] = []
            p["info"]["utility_miss_count"] = 0
            p["info"]["utility_miss_items"] = []

    # ---------- Step 4: 长度爬坡奖励 ----------
    for p in parsed:
        if p["score"] is not None:
            continue
        A, gold = p["A"], p["gold"]
        if gold:
            ratio = min(len(A), len(gold)) / max(len(A), len(gold))
        else:
            ratio = 1.0 / (1.0 + abs(len(A) - 100) / 100.0)
        length_term = LENGTH_REWARD_WEIGHT * float(ratio)
        p["info"]["length_term"] = length_term
        p["score"] = length_term

    # ---------- Step 5: 打包返回 + 可选 JSONL 日志 ----------
    # NOTE: 返回到 reward manager 的 dict 只能放标量(float / int / str)，
    # 否则 ray_trainer 里 ``np.array(v)`` 会因为变长 list / 嵌套 dict 触发
    # "inhomogeneous shape" 错误。变长结构(utility_detail / utility_miss_items)
    # 仅写入 JSONL 日志，不进 metrics。
    # 同时确保 *所有样本* 返回同一组 key(缺失值用 0.0 / "" 占位)，否则
    # defaultdict 收集出来的 list 长度会与 batch size 不一致。
    SCALAR_KEYS_DEFAULTS: dict[str, Any] = {
        "priv_max_coverage": 0.0,
        "priv_argmax_coverage": "",
        "priv_max_p_rescaled": 0.0,
        "priv_argmax_p_rescaled": "",
        "priv_ne_skipped_count": 0,
        "utility_miss_count": 0,
        "key_spans_total": 0,
        "key_spans_hit_count": 0,
        "key_spans_reward": 0.0,
        "length_term": 0.0,
        "oea_source": "origin_ea",
    }

    results: list[dict[str, Any]] = []
    log_lines: list[str] | None = [] if log_jsonl_path else None
    for i, p in enumerate(parsed):
        score = float(p["score"])
        out: dict[str, Any] = {"score": score}
        info = p["info"]
        for k, default in SCALAR_KEYS_DEFAULTS.items():
            v = info.get(k, default)
            if v is None:
                v = default
            out[k] = v
        results.append(out)

        if log_lines is not None:
            ei = extra_infos[i] or {}
            log_lines.append(json.dumps({
                "reward_score": score,
                "solution_str": solution_strs[i],
                "ne": ei.get("ne"),
                "origin_ea": ei.get("origin_ea"),
                "key_spans": ei.get("key_spans"),
                "reward_info": info,
                "question": ei.get("question"),
                "ground_truth": ground_truths[i],
                "data_source": data_sources[i],
            }, ensure_ascii=False, default=str))

    if log_lines is not None and log_lines:
        try:
            with open(log_jsonl_path, "a") as f:
                f.write("\n".join(log_lines) + "\n")
        except Exception as e:
            # 日志失败不应影响训练
            print(f"[priv_batch][warn] failed to write {log_jsonl_path}: {e!r}")

    return results


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------
# if __name__ == "__main__":
#     ground_truth = (
#         "My 74-year-old dad, a former police officer in Chicago, is struggling to "
#         "transition into security consulting or training roles. Despite his extensive "
#         "experience, he receives no callbacks. What strategies can help him overcome "
#         "this barrier and secure interviews?"
#     )
#     safe_solution = ground_truth
#     NE = [
#         "dad is absolutely losing his mind",
#         "honestly so am I on his behalf",
#         "watches the Star Wars prequels to decompress",
#         "process is stressing him out",
#     ]
#     origin_ea = ["police officer in Chicago", "74"]
#     extra_info = {"ne": NE, "origin_ea": origin_ea}

#     not_safe_solution = (
#         "My dad is absolutely losing his mind over this and honestly so am I on his "
#         "behalf. He's 74 and spent his whole career as a police officer in Chicago, "
#         "and now that he's looking to transition into something like a security "
#         "consulting or training role, every single application he submits just "
#         "disappears into a void. No callbacks, nothing. We think his age is working "
#         "against him even though he has decades of real experience. He even watches "
#         "the Star Wars prequels to decompress because this process is stressing him "
#         "out so much. What can he actually do to get past this barrier and land "
#         "interviews? Any concrete strategies would help."
#     )
#     samples = [
#         {"solution_str": safe_solution,     "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": not_safe_solution, "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": "",                "ground_truth": ground_truth, "extra_info": extra_info},
#         {"solution_str": safe_solution,     "ground_truth": ground_truth, "extra_info": extra_info},
#     ]

#     import time
#     t0 = time.time()
#     out = compute_score(
#         data_sources=["priv"] * len(samples),
#         solution_strs=[s["solution_str"] for s in samples],
#         ground_truths=[s["ground_truth"] for s in samples],
#         extra_infos=[s["extra_info"] for s in samples],
#         log_jsonl_path='zzz.jsonl',  # smoke test 时不要污染日志文件
#     )
#     print(f"batch compute_score elapsed: {time.time() - t0:.2f}s")
#     for i, r in enumerate(out):
#         print(f"--- sample {i} ---")
#         print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
